# cms.fhir.us.access#0.9.0: CMS ACCESS Model API

## Pages

* [Home](index.md)
* [Artifacts](artifacts.md)
* [Conformance Expectations](conformance.md)
* [Downloads](downloads.md)

## Resources

### CodeSystems

* [ACCESS Alignment Request Result Codes](CodeSystem-ACCESSAlignmentResultCS.md)
* [ACCESS Eligibility Result Codes](CodeSystem-ACCESSEligibilityResultCS.md)
* [ACCESS Event Types](CodeSystem-ACCESSEventTypeCS.md)
* [ACCESS Referral Type](CodeSystem-ACCESSReferralTypeCS.md)
* [ACCESS Model Tracks](CodeSystem-ACCESSTrackCS.md)
* [ACCESS Unalignment Reason Codes](CodeSystem-ACCESSUnalignmentReasonCS.md)
* [ACCESS Unalignment Request Result Codes](CodeSystem-ACCESSUnalignmentResultCS.md)

### ValueSets

* [ACCESS Alignment Result Value Set](ValueSet-ACCESSAlignmentResultVS.md)
* [ACCESS Behavioral Health (BH) Track Qualifying Diagnoses](ValueSet-ACCESSBHDiagnosisVS.md)
* [ACCESS Cardio-Kidney-Metabolic (CKM) Track Qualifying Diagnoses](ValueSet-ACCESSCKMDiagnosisVS.md)
* [ACCESS Eligibility Result Value Set](ValueSet-ACCESSEligibilityResultVS.md)
* [ACCESS Event Types Value Set](ValueSet-ACCESSEventTypeVS.md)
* [ACCESS Musculoskeletal (MSK) Track Qualifying Diagnoses](ValueSet-ACCESSMSKDiagnosisVS.md)
* [ACCESS Referral Type Value Set](ValueSet-ACCESSReferralTypeVS.md)
* [ACCESS Model Tracks Value Set](ValueSet-ACCESSTrackVS.md)
* [ACCESS Unalignment Reason Value Set](ValueSet-ACCESSUnalignmentReasonVS.md)
* [ACCESS Unalignment Result Value Set](ValueSet-ACCESSUnalignmentResultVS.md)
* [ACCESS Early Cardio-Kidney-Metabolic (eCKM) Track Qualifying Diagnoses](ValueSet-ACCESSeCKMDiagnosisVS.md)

### Resource Profiles

* [ACCESS Alignment Request Parameters](StructureDefinition-access-align-in.md)
* [ACCESS Alignment Response Parameters](StructureDefinition-access-align-out.md)
* [ACCESS BH Condition Profile](StructureDefinition-access-bh-condition.md)
* [ACCESS Check Eligibility Request Parameters](StructureDefinition-access-check-eligibility-in.md)
* [ACCESS Check Eligibility Response Parameters](StructureDefinition-access-check-eligibility-out.md)
* [ACCESS CKM Track Condition Profile](StructureDefinition-access-ckm-condition.md)
* [ACCESS Clinical Exclusion Condition](StructureDefinition-access-clinical-exclusion-condition.md)
* [ACCESS Condition Profile](StructureDefinition-access-condition.md)
* [ACCESS eCKM Track Condition Profile](StructureDefinition-access-eckm-condition.md)
* [ACCESS MSK Track Condition Profile](StructureDefinition-access-msk-condition.md)
* [ACCESS Submission Status Response Parameters](StructureDefinition-access-submission-status-out.md)
* [ACCESS Unalignment Request Parameters](StructureDefinition-access-unalign-in.md)
* [ACCESS Unalignment Response Parameters](StructureDefinition-access-unalign-out.md)

### CapabilityStatements

* [ACCESS Alignment API Capability Statement](CapabilityStatement-ACCESSAlignmentAPICapabilityStatement.md)
* [ACCESS Eligibility API Capability Statement](CapabilityStatement-ACCESSEligibilityAPICapabilityStatement.md)
* [ACCESS Unalignment API Capability Statement](CapabilityStatement-ACCESSUnalignmentAPICapabilityStatement.md)

### ImplementationGuides

* [CMS ACCESS Model API](index.md)

### OperationDefinitions

* [Alignment Request](OperationDefinition-Align.md)
* [Check Eligibility Request](OperationDefinition-CheckEligibility.md)
* [Submission Status](OperationDefinition-SubmissionStatus.md)
* [Unalignment Request](OperationDefinition-Unalign.md)

### Examples

* [ConditionDepressionExample (Condition)](Condition-ConditionDepressionExample.md)
* [ConditionDiabetesExample (Condition)](Condition-ConditionDiabetesExample.md)
* [ConditionHypertensionExample (Condition)](Condition-ConditionHypertensionExample.md)
* [ConditionOsteoarthritisExample (Condition)](Condition-ConditionOsteoarthritisExample.md)
* [ESRDConditionExample (Condition)](Condition-ESRDConditionExample.md)
* [Example Healthcare Organization (Organization)](Organization-OrganizationExample.md)
* [AlignmentRequestExample (Parameters)](Parameters-AlignmentRequestExample.md)
* [AlignmentRequestWithSwitchConsentExample (Parameters)](Parameters-AlignmentRequestWithSwitchConsentExample.md)
* [AlignmentResponseAlignedExample (Parameters)](Parameters-AlignmentResponseAlignedExample.md)
* [AlignmentResponseSwitchApprovedExample (Parameters)](Parameters-AlignmentResponseSwitchApprovedExample.md)
* [CheckEligibilityRequestExample (Parameters)](Parameters-CheckEligibilityRequestExample.md)
* [CheckEligibilityResponseEligibleExample (Parameters)](Parameters-CheckEligibilityResponseEligibleExample.md)
* [SubmissionStatusResponseExample (Parameters)](Parameters-SubmissionStatusResponseExample.md)
* [UnalignmentRequestESRDExample (Parameters)](Parameters-UnalignmentRequestESRDExample.md)
* [UnalignmentRequestExample (Parameters)](Parameters-UnalignmentRequestExample.md)
* [UnalignmentResponseUnalignedExample (Parameters)](Parameters-UnalignmentResponseUnalignedExample.md)
* [PatientESRDExample (Patient)](Patient-PatientESRDExample.md)
* [PatientExample (Patient)](Patient-PatientExample.md)
* [PractitionerExample (Practitioner)](Practitioner-PractitionerExample.md)
