# ACCESS Cardio-Kidney-Metabolic (CKM) Track Qualifying Diagnoses - CMS ACCESS Model API v0.9.11

## ValueSet: ACCESS Cardio-Kidney-Metabolic (CKM) Track Qualifying Diagnoses 

 
This value set contains ICD-10-CM diagnosis codes that qualify a patient for the ACCESS Model Cardio-Kidney-Metabolic (CKM) track. Includes diabetes mellitus (all types), atherosclerotic cardiovascular disease (ASCVD), and chronic kidney disease (CKD stage 3) diagnoses. 

 **References** 

* [ACCESS CKM Track Condition Profile](StructureDefinition-access-ckm-condition.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ACCESSCKMDiagnosisVS",
  "url" : "https://dsacms.github.io/cmmi-access-model/ValueSet/ACCESSCKMDiagnosisVS",
  "version" : "0.9.11",
  "name" : "ACCESSCKMDiagnosisVS",
  "title" : "ACCESS Cardio-Kidney-Metabolic (CKM) Track Qualifying Diagnoses",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-04T23:05:21-04:00",
  "publisher" : "Global Alliant, Inc.",
  "contact" : [{
    "name" : "Global Alliant, Inc.",
    "telecom" : [{
      "system" : "url",
      "value" : "https://globalalliantinc.com"
    },
    {
      "system" : "email",
      "value" : "david.h@globalalliantinc.org"
    }]
  }],
  "description" : "This value set contains ICD-10-CM diagnosis codes that qualify a patient for the ACCESS Model Cardio-Kidney-Metabolic (CKM) track. Includes diabetes mellitus (all types), atherosclerotic cardiovascular disease (ASCVD), and chronic kidney disease (CKD stage 3) diagnoses.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "US",
      "display" : "United States of America"
    }]
  }],
  "copyright" : "This value set includes content from ICD-10-CM, which is copyright World Health Organization (WHO). ICD-10-CM codes are freely available in the public domain.",
  "compose" : {
    "include" : [{
      "system" : "http://hl7.org/fhir/sid/icd-10-cm",
      "concept" : [{
        "code" : "E08.00",
        "display" : "Diabetes mellitus due to underlying condition with hyperosmolarity without nonketotic hyperglycemic-hyperosmolar coma (NKHHC)"
      },
      {
        "code" : "E08.01",
        "display" : "Diabetes mellitus due to underlying condition with hyperosmolarity with coma"
      },
      {
        "code" : "E08.10",
        "display" : "Diabetes mellitus due to underlying condition with ketoacidosis without coma"
      },
      {
        "code" : "E08.11",
        "display" : "Diabetes mellitus due to underlying condition with ketoacidosis with coma"
      },
      {
        "code" : "E08.21",
        "display" : "Diabetes mellitus due to underlying condition with diabetic nephropathy"
      },
      {
        "code" : "E08.22",
        "display" : "Diabetes mellitus due to underlying condition with diabetic chronic kidney disease"
      },
      {
        "code" : "E08.29",
        "display" : "Diabetes mellitus due to underlying condition with other diabetic kidney complication"
      },
      {
        "code" : "E08.311",
        "display" : "Diabetes mellitus due to underlying condition with unspecified diabetic retinopathy with macular edema"
      },
      {
        "code" : "E08.319",
        "display" : "Diabetes mellitus due to underlying condition with unspecified diabetic retinopathy without macular edema"
      },
      {
        "code" : "E08.3211",
        "display" : "Diabetes mellitus due to underlying condition with mild nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E08.3212",
        "display" : "Diabetes mellitus due to underlying condition with mild nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E08.3213",
        "display" : "Diabetes mellitus due to underlying condition with mild nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E08.3219",
        "display" : "Diabetes mellitus due to underlying condition with mild nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E08.3291",
        "display" : "Diabetes mellitus due to underlying condition with mild nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E08.3292",
        "display" : "Diabetes mellitus due to underlying condition with mild nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E08.3293",
        "display" : "Diabetes mellitus due to underlying condition with mild nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E08.3299",
        "display" : "Diabetes mellitus due to underlying condition with mild nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E08.3311",
        "display" : "Diabetes mellitus due to underlying condition with moderate nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E08.3312",
        "display" : "Diabetes mellitus due to underlying condition with moderate nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E08.3313",
        "display" : "Diabetes mellitus due to underlying condition with moderate nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E08.3319",
        "display" : "Diabetes mellitus due to underlying condition with moderate nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E08.3391",
        "display" : "Diabetes mellitus due to underlying condition with moderate nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E08.3392",
        "display" : "Diabetes mellitus due to underlying condition with moderate nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E08.3393",
        "display" : "Diabetes mellitus due to underlying condition with moderate nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E08.3399",
        "display" : "Diabetes mellitus due to underlying condition with moderate nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E08.3411",
        "display" : "Diabetes mellitus due to underlying condition with severe nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E08.3412",
        "display" : "Diabetes mellitus due to underlying condition with severe nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E08.3413",
        "display" : "Diabetes mellitus due to underlying condition with severe nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E08.3419",
        "display" : "Diabetes mellitus due to underlying condition with severe nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E08.3491",
        "display" : "Diabetes mellitus due to underlying condition with severe nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E08.3492",
        "display" : "Diabetes mellitus due to underlying condition with severe nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E08.3493",
        "display" : "Diabetes mellitus due to underlying condition with severe nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E08.3499",
        "display" : "Diabetes mellitus due to underlying condition with severe nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E08.3511",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E08.3512",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E08.3513",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E08.3519",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E08.3521",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with traction retinal detachment involving the macula, right eye"
      },
      {
        "code" : "E08.3522",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with traction retinal detachment involving the macula, left eye"
      },
      {
        "code" : "E08.3523",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with traction retinal detachment involving the macula, bilateral"
      },
      {
        "code" : "E08.3529",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with traction retinal detachment involving the macula, unspecified eye"
      },
      {
        "code" : "E08.3531",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, right eye"
      },
      {
        "code" : "E08.3532",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, left eye"
      },
      {
        "code" : "E08.3533",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, bilateral"
      },
      {
        "code" : "E08.3539",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, unspecified eye"
      },
      {
        "code" : "E08.3541",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, right eye"
      },
      {
        "code" : "E08.3542",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, left eye"
      },
      {
        "code" : "E08.3543",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, bilateral"
      },
      {
        "code" : "E08.3549",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, unspecified eye"
      },
      {
        "code" : "E08.3551",
        "display" : "Diabetes mellitus due to underlying condition with stable proliferative diabetic retinopathy, right eye"
      },
      {
        "code" : "E08.3552",
        "display" : "Diabetes mellitus due to underlying condition with stable proliferative diabetic retinopathy, left eye"
      },
      {
        "code" : "E08.3553",
        "display" : "Diabetes mellitus due to underlying condition with stable proliferative diabetic retinopathy, bilateral"
      },
      {
        "code" : "E08.3559",
        "display" : "Diabetes mellitus due to underlying condition with stable proliferative diabetic retinopathy, unspecified eye"
      },
      {
        "code" : "E08.3591",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E08.3592",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E08.3593",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E08.3599",
        "display" : "Diabetes mellitus due to underlying condition with proliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E08.36",
        "display" : "Diabetes mellitus due to underlying condition with diabetic cataract"
      },
      {
        "code" : "E08.37X1",
        "display" : "Diabetes mellitus due to underlying condition with diabetic macular edema, resolved following treatment, right eye"
      },
      {
        "code" : "E08.37X2",
        "display" : "Diabetes mellitus due to underlying condition with diabetic macular edema, resolved following treatment, left eye"
      },
      {
        "code" : "E08.37X3",
        "display" : "Diabetes mellitus due to underlying condition with diabetic macular edema, resolved following treatment, bilateral"
      },
      {
        "code" : "E08.37X9",
        "display" : "Diabetes mellitus due to underlying condition with diabetic macular edema, resolved following treatment, unspecified eye"
      },
      {
        "code" : "E08.39",
        "display" : "Diabetes mellitus due to underlying condition with other diabetic ophthalmic complication"
      },
      {
        "code" : "E08.40",
        "display" : "Diabetes mellitus due to underlying condition with diabetic neuropathy, unspecified"
      },
      {
        "code" : "E08.41",
        "display" : "Diabetes mellitus due to underlying condition with diabetic mononeuropathy"
      },
      {
        "code" : "E08.42",
        "display" : "Diabetes mellitus due to underlying condition with diabetic polyneuropathy"
      },
      {
        "code" : "E08.43",
        "display" : "Diabetes mellitus due to underlying condition with diabetic autonomic (poly)neuropathy"
      },
      {
        "code" : "E08.44",
        "display" : "Diabetes mellitus due to underlying condition with diabetic amyotrophy"
      },
      {
        "code" : "E08.49",
        "display" : "Diabetes mellitus due to underlying condition with other diabetic neurological complication"
      },
      {
        "code" : "E08.51",
        "display" : "Diabetes mellitus due to underlying condition with diabetic peripheral angiopathy without gangrene"
      },
      {
        "code" : "E08.52",
        "display" : "Diabetes mellitus due to underlying condition with diabetic peripheral angiopathy with gangrene"
      },
      {
        "code" : "E08.59",
        "display" : "Diabetes mellitus due to underlying condition with other circulatory complications"
      },
      {
        "code" : "E08.610",
        "display" : "Diabetes mellitus due to underlying condition with diabetic neuropathic arthropathy"
      },
      {
        "code" : "E08.618",
        "display" : "Diabetes mellitus due to underlying condition with other diabetic arthropathy"
      },
      {
        "code" : "E08.620",
        "display" : "Diabetes mellitus due to underlying condition with diabetic dermatitis"
      },
      {
        "code" : "E08.621",
        "display" : "Diabetes mellitus due to underlying condition with foot ulcer"
      },
      {
        "code" : "E08.622",
        "display" : "Diabetes mellitus due to underlying condition with other skin ulcer"
      },
      {
        "code" : "E08.628",
        "display" : "Diabetes mellitus due to underlying condition with other skin complications"
      },
      {
        "code" : "E08.630",
        "display" : "Diabetes mellitus due to underlying condition with periodontal disease"
      },
      {
        "code" : "E08.638",
        "display" : "Diabetes mellitus due to underlying condition with other oral complications"
      },
      {
        "code" : "E08.641",
        "display" : "Diabetes mellitus due to underlying condition with hypoglycemia with coma"
      },
      {
        "code" : "E08.649",
        "display" : "Diabetes mellitus due to underlying condition with hypoglycemia without coma"
      },
      {
        "code" : "E08.65",
        "display" : "Diabetes mellitus due to underlying condition with hyperglycemia"
      },
      {
        "code" : "E08.69",
        "display" : "Diabetes mellitus due to underlying condition with other specified complication"
      },
      {
        "code" : "E08.8",
        "display" : "Diabetes mellitus due to underlying condition with unspecified complications"
      },
      {
        "code" : "E08.9",
        "display" : "Diabetes mellitus due to underlying condition without complications"
      },
      {
        "code" : "E09.00",
        "display" : "Drug or chemical induced diabetes mellitus with hyperosmolarity without nonketotic hyperglycemic-hyperosmolar coma (NKHHC)"
      },
      {
        "code" : "E09.01",
        "display" : "Drug or chemical induced diabetes mellitus with hyperosmolarity with coma"
      },
      {
        "code" : "E09.10",
        "display" : "Drug or chemical induced diabetes mellitus with ketoacidosis without coma"
      },
      {
        "code" : "E09.11",
        "display" : "Drug or chemical induced diabetes mellitus with ketoacidosis with coma"
      },
      {
        "code" : "E09.21",
        "display" : "Drug or chemical induced diabetes mellitus with diabetic nephropathy"
      },
      {
        "code" : "E09.22",
        "display" : "Drug or chemical induced diabetes mellitus with diabetic chronic kidney disease"
      },
      {
        "code" : "E09.29",
        "display" : "Drug or chemical induced diabetes mellitus with other diabetic kidney complication"
      },
      {
        "code" : "E09.311",
        "display" : "Drug or chemical induced diabetes mellitus with unspecified diabetic retinopathy with macular edema"
      },
      {
        "code" : "E09.319",
        "display" : "Drug or chemical induced diabetes mellitus with unspecified diabetic retinopathy without macular edema"
      },
      {
        "code" : "E09.3211",
        "display" : "Drug or chemical induced diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E09.3212",
        "display" : "Drug or chemical induced diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E09.3213",
        "display" : "Drug or chemical induced diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E09.3219",
        "display" : "Drug or chemical induced diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E09.3291",
        "display" : "Drug or chemical induced diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E09.3292",
        "display" : "Drug or chemical induced diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E09.3293",
        "display" : "Drug or chemical induced diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E09.3299",
        "display" : "Drug or chemical induced diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E09.3311",
        "display" : "Drug or chemical induced diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E09.3312",
        "display" : "Drug or chemical induced diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E09.3313",
        "display" : "Drug or chemical induced diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E09.3319",
        "display" : "Drug or chemical induced diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E09.3391",
        "display" : "Drug or chemical induced diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E09.3392",
        "display" : "Drug or chemical induced diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E09.3393",
        "display" : "Drug or chemical induced diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E09.3399",
        "display" : "Drug or chemical induced diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E09.3411",
        "display" : "Drug or chemical induced diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E09.3412",
        "display" : "Drug or chemical induced diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E09.3413",
        "display" : "Drug or chemical induced diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E09.3419",
        "display" : "Drug or chemical induced diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E09.3491",
        "display" : "Drug or chemical induced diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E09.3492",
        "display" : "Drug or chemical induced diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E09.3493",
        "display" : "Drug or chemical induced diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E09.3499",
        "display" : "Drug or chemical induced diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E09.3511",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E09.3512",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E09.3513",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E09.3519",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E09.3521",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, right eye"
      },
      {
        "code" : "E09.3522",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, left eye"
      },
      {
        "code" : "E09.3523",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, bilateral"
      },
      {
        "code" : "E09.3529",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, unspecified eye"
      },
      {
        "code" : "E09.3531",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, right eye"
      },
      {
        "code" : "E09.3532",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, left eye"
      },
      {
        "code" : "E09.3533",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, bilateral"
      },
      {
        "code" : "E09.3539",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, unspecified eye"
      },
      {
        "code" : "E09.3541",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, right eye"
      },
      {
        "code" : "E09.3542",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, left eye"
      },
      {
        "code" : "E09.3543",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, bilateral"
      },
      {
        "code" : "E09.3549",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, unspecified eye"
      },
      {
        "code" : "E09.3551",
        "display" : "Drug or chemical induced diabetes mellitus with stable proliferative diabetic retinopathy, right eye"
      },
      {
        "code" : "E09.3552",
        "display" : "Drug or chemical induced diabetes mellitus with stable proliferative diabetic retinopathy, left eye"
      },
      {
        "code" : "E09.3553",
        "display" : "Drug or chemical induced diabetes mellitus with stable proliferative diabetic retinopathy, bilateral"
      },
      {
        "code" : "E09.3559",
        "display" : "Drug or chemical induced diabetes mellitus with stable proliferative diabetic retinopathy, unspecified eye"
      },
      {
        "code" : "E09.3591",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E09.3592",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E09.3593",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E09.3599",
        "display" : "Drug or chemical induced diabetes mellitus with proliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E09.36",
        "display" : "Drug or chemical induced diabetes mellitus with diabetic cataract"
      },
      {
        "code" : "E09.37X1",
        "display" : "Drug or chemical induced diabetes mellitus with diabetic macular edema, resolved following treatment, right eye"
      },
      {
        "code" : "E09.37X2",
        "display" : "Drug or chemical induced diabetes mellitus with diabetic macular edema, resolved following treatment, left eye"
      },
      {
        "code" : "E09.37X3",
        "display" : "Drug or chemical induced diabetes mellitus with diabetic macular edema, resolved following treatment, bilateral"
      },
      {
        "code" : "E09.37X9",
        "display" : "Drug or chemical induced diabetes mellitus with diabetic macular edema, resolved following treatment, unspecified eye"
      },
      {
        "code" : "E09.39",
        "display" : "Drug or chemical induced diabetes mellitus with other diabetic ophthalmic complication"
      },
      {
        "code" : "E09.40",
        "display" : "Drug or chemical induced diabetes mellitus with neurological complications with diabetic neuropathy, unspecified"
      },
      {
        "code" : "E09.41",
        "display" : "Drug or chemical induced diabetes mellitus with neurological complications with diabetic mononeuropathy"
      },
      {
        "code" : "E09.42",
        "display" : "Drug or chemical induced diabetes mellitus with neurological complications with diabetic polyneuropathy"
      },
      {
        "code" : "E09.43",
        "display" : "Drug or chemical induced diabetes mellitus with neurological complications with diabetic autonomic (poly)neuropathy"
      },
      {
        "code" : "E09.44",
        "display" : "Drug or chemical induced diabetes mellitus with neurological complications with diabetic amyotrophy"
      },
      {
        "code" : "E09.49",
        "display" : "Drug or chemical induced diabetes mellitus with neurological complications with other diabetic neurological complication"
      },
      {
        "code" : "E09.51",
        "display" : "Drug or chemical induced diabetes mellitus with diabetic peripheral angiopathy without gangrene"
      },
      {
        "code" : "E09.52",
        "display" : "Drug or chemical induced diabetes mellitus with diabetic peripheral angiopathy with gangrene"
      },
      {
        "code" : "E09.59",
        "display" : "Drug or chemical induced diabetes mellitus with other circulatory complications"
      },
      {
        "code" : "E09.610",
        "display" : "Drug or chemical induced diabetes mellitus with diabetic neuropathic arthropathy"
      },
      {
        "code" : "E09.618",
        "display" : "Drug or chemical induced diabetes mellitus with other diabetic arthropathy"
      },
      {
        "code" : "E09.620",
        "display" : "Drug or chemical induced diabetes mellitus with diabetic dermatitis"
      },
      {
        "code" : "E09.621",
        "display" : "Drug or chemical induced diabetes mellitus with foot ulcer"
      },
      {
        "code" : "E09.622",
        "display" : "Drug or chemical induced diabetes mellitus with other skin ulcer"
      },
      {
        "code" : "E09.628",
        "display" : "Drug or chemical induced diabetes mellitus with other skin complications"
      },
      {
        "code" : "E09.630",
        "display" : "Drug or chemical induced diabetes mellitus with periodontal disease"
      },
      {
        "code" : "E09.638",
        "display" : "Drug or chemical induced diabetes mellitus with other oral complications"
      },
      {
        "code" : "E09.641",
        "display" : "Drug or chemical induced diabetes mellitus with hypoglycemia with coma"
      },
      {
        "code" : "E09.649",
        "display" : "Drug or chemical induced diabetes mellitus with hypoglycemia without coma"
      },
      {
        "code" : "E09.65",
        "display" : "Drug or chemical induced diabetes mellitus with hyperglycemia"
      },
      {
        "code" : "E09.69",
        "display" : "Drug or chemical induced diabetes mellitus with other specified complication"
      },
      {
        "code" : "E09.8",
        "display" : "Drug or chemical induced diabetes mellitus with unspecified complications"
      },
      {
        "code" : "E09.9",
        "display" : "Drug or chemical induced diabetes mellitus without complications"
      },
      {
        "code" : "E11.00",
        "display" : "Type 2 diabetes mellitus with hyperosmolarity without nonketotic hyperglycemic-hyperosmolar coma (NKHHC)"
      },
      {
        "code" : "E11.01",
        "display" : "Type 2 diabetes mellitus with hyperosmolarity with coma"
      },
      {
        "code" : "E11.10",
        "display" : "Type 2 diabetes mellitus with ketoacidosis without coma"
      },
      {
        "code" : "E11.11",
        "display" : "Type 2 diabetes mellitus with ketoacidosis with coma"
      },
      {
        "code" : "E11.21",
        "display" : "Type 2 diabetes mellitus with diabetic nephropathy"
      },
      {
        "code" : "E11.22",
        "display" : "Type 2 diabetes mellitus with diabetic chronic kidney disease"
      },
      {
        "code" : "E11.29",
        "display" : "Type 2 diabetes mellitus with other diabetic kidney complication"
      },
      {
        "code" : "E11.311",
        "display" : "Type 2 diabetes mellitus with unspecified diabetic retinopathy with macular edema"
      },
      {
        "code" : "E11.319",
        "display" : "Type 2 diabetes mellitus with unspecified diabetic retinopathy without macular edema"
      },
      {
        "code" : "E11.3211",
        "display" : "Type 2 diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E11.3212",
        "display" : "Type 2 diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E11.3213",
        "display" : "Type 2 diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E11.3219",
        "display" : "Type 2 diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E11.3291",
        "display" : "Type 2 diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E11.3292",
        "display" : "Type 2 diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E11.3293",
        "display" : "Type 2 diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E11.3299",
        "display" : "Type 2 diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E11.3311",
        "display" : "Type 2 diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E11.3312",
        "display" : "Type 2 diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E11.3313",
        "display" : "Type 2 diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E11.3319",
        "display" : "Type 2 diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E11.3391",
        "display" : "Type 2 diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E11.3392",
        "display" : "Type 2 diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E11.3393",
        "display" : "Type 2 diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E11.3399",
        "display" : "Type 2 diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E11.3411",
        "display" : "Type 2 diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E11.3412",
        "display" : "Type 2 diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E11.3413",
        "display" : "Type 2 diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E11.3419",
        "display" : "Type 2 diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E11.3491",
        "display" : "Type 2 diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E11.3492",
        "display" : "Type 2 diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E11.3493",
        "display" : "Type 2 diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E11.3499",
        "display" : "Type 2 diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E11.3511",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E11.3512",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E11.3513",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E11.3519",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E11.3521",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, right eye"
      },
      {
        "code" : "E11.3522",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, left eye"
      },
      {
        "code" : "E11.3523",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, bilateral"
      },
      {
        "code" : "E11.3529",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, unspecified eye"
      },
      {
        "code" : "E11.3531",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, right eye"
      },
      {
        "code" : "E11.3532",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, left eye"
      },
      {
        "code" : "E11.3533",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, bilateral"
      },
      {
        "code" : "E11.3539",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, unspecified eye"
      },
      {
        "code" : "E11.3541",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, right eye"
      },
      {
        "code" : "E11.3542",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, left eye"
      },
      {
        "code" : "E11.3543",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, bilateral"
      },
      {
        "code" : "E11.3549",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, unspecified eye"
      },
      {
        "code" : "E11.3551",
        "display" : "Type 2 diabetes mellitus with stable proliferative diabetic retinopathy, right eye"
      },
      {
        "code" : "E11.3552",
        "display" : "Type 2 diabetes mellitus with stable proliferative diabetic retinopathy, left eye"
      },
      {
        "code" : "E11.3553",
        "display" : "Type 2 diabetes mellitus with stable proliferative diabetic retinopathy, bilateral"
      },
      {
        "code" : "E11.3559",
        "display" : "Type 2 diabetes mellitus with stable proliferative diabetic retinopathy, unspecified eye"
      },
      {
        "code" : "E11.3591",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E11.3592",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E11.3593",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E11.3599",
        "display" : "Type 2 diabetes mellitus with proliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E11.36",
        "display" : "Type 2 diabetes mellitus with diabetic cataract"
      },
      {
        "code" : "E11.37X1",
        "display" : "Type 2 diabetes mellitus with diabetic macular edema, resolved following treatment, right eye"
      },
      {
        "code" : "E11.37X2",
        "display" : "Type 2 diabetes mellitus with diabetic macular edema, resolved following treatment, left eye"
      },
      {
        "code" : "E11.37X3",
        "display" : "Type 2 diabetes mellitus with diabetic macular edema, resolved following treatment, bilateral"
      },
      {
        "code" : "E11.37X9",
        "display" : "Type 2 diabetes mellitus with diabetic macular edema, resolved following treatment, unspecified eye"
      },
      {
        "code" : "E11.39",
        "display" : "Type 2 diabetes mellitus with other diabetic ophthalmic complication"
      },
      {
        "code" : "E11.40",
        "display" : "Type 2 diabetes mellitus with diabetic neuropathy, unspecified"
      },
      {
        "code" : "E11.41",
        "display" : "Type 2 diabetes mellitus with diabetic mononeuropathy"
      },
      {
        "code" : "E11.42",
        "display" : "Type 2 diabetes mellitus with diabetic polyneuropathy"
      },
      {
        "code" : "E11.43",
        "display" : "Type 2 diabetes mellitus with diabetic autonomic (poly)neuropathy"
      },
      {
        "code" : "E11.44",
        "display" : "Type 2 diabetes mellitus with diabetic amyotrophy"
      },
      {
        "code" : "E11.49",
        "display" : "Type 2 diabetes mellitus with other diabetic neurological complication"
      },
      {
        "code" : "E11.51",
        "display" : "Type 2 diabetes mellitus with diabetic peripheral angiopathy without gangrene"
      },
      {
        "code" : "E11.52",
        "display" : "Type 2 diabetes mellitus with diabetic peripheral angiopathy with gangrene"
      },
      {
        "code" : "E11.59",
        "display" : "Type 2 diabetes mellitus with other circulatory complications"
      },
      {
        "code" : "E11.610",
        "display" : "Type 2 diabetes mellitus with diabetic neuropathic arthropathy"
      },
      {
        "code" : "E11.618",
        "display" : "Type 2 diabetes mellitus with other diabetic arthropathy"
      },
      {
        "code" : "E11.620",
        "display" : "Type 2 diabetes mellitus with diabetic dermatitis"
      },
      {
        "code" : "E11.621",
        "display" : "Type 2 diabetes mellitus with foot ulcer"
      },
      {
        "code" : "E11.622",
        "display" : "Type 2 diabetes mellitus with other skin ulcer"
      },
      {
        "code" : "E11.628",
        "display" : "Type 2 diabetes mellitus with other skin complications"
      },
      {
        "code" : "E11.630",
        "display" : "Type 2 diabetes mellitus with periodontal disease"
      },
      {
        "code" : "E11.638",
        "display" : "Type 2 diabetes mellitus with other oral complications"
      },
      {
        "code" : "E11.641",
        "display" : "Type 2 diabetes mellitus with hypoglycemia with coma"
      },
      {
        "code" : "E11.649",
        "display" : "Type 2 diabetes mellitus with hypoglycemia without coma"
      },
      {
        "code" : "E11.65",
        "display" : "Type 2 diabetes mellitus with hyperglycemia"
      },
      {
        "code" : "E11.69",
        "display" : "Type 2 diabetes mellitus with other specified complication"
      },
      {
        "code" : "E11.8",
        "display" : "Type 2 diabetes mellitus with unspecified complications"
      },
      {
        "code" : "E11.9",
        "display" : "Type 2 diabetes mellitus without complications"
      },
      {
        "code" : "E11.A",
        "display" : "Type 2 diabetes mellitus without complications in remission"
      },
      {
        "code" : "E13.00",
        "display" : "Other specified diabetes mellitus with hyperosmolarity without nonketotic hyperglycemic-hyperosmolar coma (NKHHC)"
      },
      {
        "code" : "E13.01",
        "display" : "Other specified diabetes mellitus with hyperosmolarity with coma"
      },
      {
        "code" : "E13.10",
        "display" : "Other specified diabetes mellitus with ketoacidosis without coma"
      },
      {
        "code" : "E13.11",
        "display" : "Other specified diabetes mellitus with ketoacidosis with coma"
      },
      {
        "code" : "E13.21",
        "display" : "Other specified diabetes mellitus with diabetic nephropathy"
      },
      {
        "code" : "E13.22",
        "display" : "Other specified diabetes mellitus with diabetic chronic kidney disease"
      },
      {
        "code" : "E13.29",
        "display" : "Other specified diabetes mellitus with other diabetic kidney complication"
      },
      {
        "code" : "E13.311",
        "display" : "Other specified diabetes mellitus with unspecified diabetic retinopathy with macular edema"
      },
      {
        "code" : "E13.319",
        "display" : "Other specified diabetes mellitus with unspecified diabetic retinopathy without macular edema"
      },
      {
        "code" : "E13.3211",
        "display" : "Other specified diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E13.3212",
        "display" : "Other specified diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E13.3213",
        "display" : "Other specified diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E13.3219",
        "display" : "Other specified diabetes mellitus with mild nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E13.3291",
        "display" : "Other specified diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E13.3292",
        "display" : "Other specified diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E13.3293",
        "display" : "Other specified diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E13.3299",
        "display" : "Other specified diabetes mellitus with mild nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E13.3311",
        "display" : "Other specified diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E13.3312",
        "display" : "Other specified diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E13.3313",
        "display" : "Other specified diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E13.3319",
        "display" : "Other specified diabetes mellitus with moderate nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E13.3391",
        "display" : "Other specified diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E13.3392",
        "display" : "Other specified diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E13.3393",
        "display" : "Other specified diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E13.3399",
        "display" : "Other specified diabetes mellitus with moderate nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E13.3411",
        "display" : "Other specified diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E13.3412",
        "display" : "Other specified diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E13.3413",
        "display" : "Other specified diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E13.3419",
        "display" : "Other specified diabetes mellitus with severe nonproliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E13.3491",
        "display" : "Other specified diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E13.3492",
        "display" : "Other specified diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E13.3493",
        "display" : "Other specified diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E13.3499",
        "display" : "Other specified diabetes mellitus with severe nonproliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E13.3511",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with macular edema, right eye"
      },
      {
        "code" : "E13.3512",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with macular edema, left eye"
      },
      {
        "code" : "E13.3513",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with macular edema, bilateral"
      },
      {
        "code" : "E13.3519",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with macular edema, unspecified eye"
      },
      {
        "code" : "E13.3521",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, right eye"
      },
      {
        "code" : "E13.3522",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, left eye"
      },
      {
        "code" : "E13.3523",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, bilateral"
      },
      {
        "code" : "E13.3529",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment involving the macula, unspecified eye"
      },
      {
        "code" : "E13.3531",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, right eye"
      },
      {
        "code" : "E13.3532",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, left eye"
      },
      {
        "code" : "E13.3533",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, bilateral"
      },
      {
        "code" : "E13.3539",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with traction retinal detachment not involving the macula, unspecified eye"
      },
      {
        "code" : "E13.3541",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, right eye"
      },
      {
        "code" : "E13.3542",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, left eye"
      },
      {
        "code" : "E13.3543",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, bilateral"
      },
      {
        "code" : "E13.3549",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy with combined traction retinal detachment and rhegmatogenous retinal detachment, unspecified eye"
      },
      {
        "code" : "E13.3551",
        "display" : "Other specified diabetes mellitus with stable proliferative diabetic retinopathy, right eye"
      },
      {
        "code" : "E13.3552",
        "display" : "Other specified diabetes mellitus with stable proliferative diabetic retinopathy, left eye"
      },
      {
        "code" : "E13.3553",
        "display" : "Other specified diabetes mellitus with stable proliferative diabetic retinopathy, bilateral"
      },
      {
        "code" : "E13.3559",
        "display" : "Other specified diabetes mellitus with stable proliferative diabetic retinopathy, unspecified eye"
      },
      {
        "code" : "E13.3591",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy without macular edema, right eye"
      },
      {
        "code" : "E13.3592",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy without macular edema, left eye"
      },
      {
        "code" : "E13.3593",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy without macular edema, bilateral"
      },
      {
        "code" : "E13.3599",
        "display" : "Other specified diabetes mellitus with proliferative diabetic retinopathy without macular edema, unspecified eye"
      },
      {
        "code" : "E13.36",
        "display" : "Other specified diabetes mellitus with diabetic cataract"
      },
      {
        "code" : "E13.37X1",
        "display" : "Other specified diabetes mellitus with diabetic macular edema, resolved following treatment, right eye"
      },
      {
        "code" : "E13.37X2",
        "display" : "Other specified diabetes mellitus with diabetic macular edema, resolved following treatment, left eye"
      },
      {
        "code" : "E13.37X3",
        "display" : "Other specified diabetes mellitus with diabetic macular edema, resolved following treatment, bilateral"
      },
      {
        "code" : "E13.37X9",
        "display" : "Other specified diabetes mellitus with diabetic macular edema, resolved following treatment, unspecified eye"
      },
      {
        "code" : "E13.39",
        "display" : "Other specified diabetes mellitus with other diabetic ophthalmic complication"
      },
      {
        "code" : "E13.40",
        "display" : "Other specified diabetes mellitus with diabetic neuropathy, unspecified"
      },
      {
        "code" : "E13.41",
        "display" : "Other specified diabetes mellitus with diabetic mononeuropathy"
      },
      {
        "code" : "E13.42",
        "display" : "Other specified diabetes mellitus with diabetic polyneuropathy"
      },
      {
        "code" : "E13.43",
        "display" : "Other specified diabetes mellitus with diabetic autonomic (poly)neuropathy"
      },
      {
        "code" : "E13.44",
        "display" : "Other specified diabetes mellitus with diabetic amyotrophy"
      },
      {
        "code" : "E13.49",
        "display" : "Other specified diabetes mellitus with other diabetic neurological complication"
      },
      {
        "code" : "E13.51",
        "display" : "Other specified diabetes mellitus with diabetic peripheral angiopathy without gangrene"
      },
      {
        "code" : "E13.52",
        "display" : "Other specified diabetes mellitus with diabetic peripheral angiopathy with gangrene"
      },
      {
        "code" : "E13.59",
        "display" : "Other specified diabetes mellitus with other circulatory complications"
      },
      {
        "code" : "E13.610",
        "display" : "Other specified diabetes mellitus with diabetic neuropathic arthropathy"
      },
      {
        "code" : "E13.618",
        "display" : "Other specified diabetes mellitus with other diabetic arthropathy"
      },
      {
        "code" : "E13.620",
        "display" : "Other specified diabetes mellitus with diabetic dermatitis"
      },
      {
        "code" : "E13.621",
        "display" : "Other specified diabetes mellitus with foot ulcer"
      },
      {
        "code" : "E13.622",
        "display" : "Other specified diabetes mellitus with other skin ulcer"
      },
      {
        "code" : "E13.628",
        "display" : "Other specified diabetes mellitus with other skin complications"
      },
      {
        "code" : "E13.630",
        "display" : "Other specified diabetes mellitus with periodontal disease"
      },
      {
        "code" : "E13.638",
        "display" : "Other specified diabetes mellitus with other oral complications"
      },
      {
        "code" : "E13.641",
        "display" : "Other specified diabetes mellitus with hypoglycemia with coma"
      },
      {
        "code" : "E13.649",
        "display" : "Other specified diabetes mellitus with hypoglycemia without coma"
      },
      {
        "code" : "E13.65",
        "display" : "Other specified diabetes mellitus with hyperglycemia"
      },
      {
        "code" : "E13.69",
        "display" : "Other specified diabetes mellitus with other specified complication"
      },
      {
        "code" : "E13.8",
        "display" : "Other specified diabetes mellitus with unspecified complications"
      },
      {
        "code" : "E13.9",
        "display" : "Other specified diabetes mellitus without complications"
      },
      {
        "code" : "G45.0",
        "display" : "Vertebro-basilar artery syndrome"
      },
      {
        "code" : "G45.1",
        "display" : "Carotid artery syndrome (hemispheric)"
      },
      {
        "code" : "G45.2",
        "display" : "Multiple and bilateral precerebral artery syndromes"
      },
      {
        "code" : "G45.3",
        "display" : "Amaurosis fugax"
      },
      {
        "code" : "G45.4",
        "display" : "Transient global amnesia"
      },
      {
        "code" : "G45.8",
        "display" : "Other transient cerebral ischemic attacks and related syndromes"
      },
      {
        "code" : "G45.9",
        "display" : "Transient cerebral ischemic attack, unspecified"
      },
      {
        "code" : "I20.0",
        "display" : "Unstable angina"
      },
      {
        "code" : "I20.1",
        "display" : "Angina pectoris with documented spasm"
      },
      {
        "code" : "I20.2",
        "display" : "Refractory angina pectoris"
      },
      {
        "code" : "I20.81",
        "display" : "Angina pectoris with coronary microvascular dysfunction"
      },
      {
        "code" : "I20.89",
        "display" : "Other forms of angina pectoris"
      },
      {
        "code" : "I20.9",
        "display" : "Angina pectoris, unspecified"
      },
      {
        "code" : "I25.10",
        "display" : "Atherosclerotic heart disease of native coronary artery without angina pectoris"
      },
      {
        "code" : "I25.110",
        "display" : "Atherosclerotic heart disease of native coronary artery with unstable angina pectoris"
      },
      {
        "code" : "I25.111",
        "display" : "Atherosclerotic heart disease of native coronary artery with angina pectoris with documented spasm"
      },
      {
        "code" : "I25.112",
        "display" : "Atherosclerotic heart disease of native coronary artery with refractory angina pectoris"
      },
      {
        "code" : "I25.118",
        "display" : "Atherosclerotic heart disease of native coronary artery with other forms of angina pectoris"
      },
      {
        "code" : "I25.119",
        "display" : "Atherosclerotic heart disease of native coronary artery with unspecified angina pectoris"
      },
      {
        "code" : "I25.2",
        "display" : "Old myocardial infarction"
      },
      {
        "code" : "I25.3",
        "display" : "Aneurysm of heart"
      },
      {
        "code" : "I25.41",
        "display" : "Coronary artery aneurysm"
      },
      {
        "code" : "I25.42",
        "display" : "Coronary artery dissection"
      },
      {
        "code" : "I25.5",
        "display" : "Ischemic cardiomyopathy"
      },
      {
        "code" : "I25.6",
        "display" : "Silent myocardial ischemia"
      },
      {
        "code" : "I25.700",
        "display" : "Atherosclerosis of coronary artery bypass graft(s), unspecified, with unstable angina pectoris"
      },
      {
        "code" : "I25.701",
        "display" : "Atherosclerosis of coronary artery bypass graft(s), unspecified, with angina pectoris with documented spasm"
      },
      {
        "code" : "I25.702",
        "display" : "Atherosclerosis of coronary artery bypass graft(s), unspecified, with refractory angina pectoris"
      },
      {
        "code" : "I25.708",
        "display" : "Atherosclerosis of coronary artery bypass graft(s), unspecified, with other forms of angina pectoris"
      },
      {
        "code" : "I25.709",
        "display" : "Atherosclerosis of coronary artery bypass graft(s), unspecified, with unspecified angina pectoris"
      },
      {
        "code" : "I25.710",
        "display" : "Atherosclerosis of autologous vein coronary artery bypass graft(s) with unstable angina pectoris"
      },
      {
        "code" : "I25.711",
        "display" : "Atherosclerosis of autologous vein coronary artery bypass graft(s) with angina pectoris with documented spasm"
      },
      {
        "code" : "I25.712",
        "display" : "Atherosclerosis of autologous vein coronary artery bypass graft(s) with refractory angina pectoris"
      },
      {
        "code" : "I25.718",
        "display" : "Atherosclerosis of autologous vein coronary artery bypass graft(s) with other forms of angina pectoris"
      },
      {
        "code" : "I25.719",
        "display" : "Atherosclerosis of autologous vein coronary artery bypass graft(s) with unspecified angina pectoris"
      },
      {
        "code" : "I25.720",
        "display" : "Atherosclerosis of autologous artery coronary artery bypass graft(s) with unstable angina pectoris"
      },
      {
        "code" : "I25.721",
        "display" : "Atherosclerosis of autologous artery coronary artery bypass graft(s) with angina pectoris with documented spasm"
      },
      {
        "code" : "I25.722",
        "display" : "Atherosclerosis of autologous artery coronary artery bypass graft(s) with refractory angina pectoris"
      },
      {
        "code" : "I25.728",
        "display" : "Atherosclerosis of autologous artery coronary artery bypass graft(s) with other forms of angina pectoris"
      },
      {
        "code" : "I25.729",
        "display" : "Atherosclerosis of autologous artery coronary artery bypass graft(s) with unspecified angina pectoris"
      },
      {
        "code" : "I25.730",
        "display" : "Atherosclerosis of nonautologous biological coronary artery bypass graft(s) with unstable angina pectoris"
      },
      {
        "code" : "I25.731",
        "display" : "Atherosclerosis of nonautologous biological coronary artery bypass graft(s) with angina pectoris with documented spasm"
      },
      {
        "code" : "I25.732",
        "display" : "Atherosclerosis of nonautologous biological coronary artery bypass graft(s) with refractory angina pectoris"
      },
      {
        "code" : "I25.738",
        "display" : "Atherosclerosis of nonautologous biological coronary artery bypass graft(s) with other forms of angina pectoris"
      },
      {
        "code" : "I25.739",
        "display" : "Atherosclerosis of nonautologous biological coronary artery bypass graft(s) with unspecified angina pectoris"
      },
      {
        "code" : "I25.750",
        "display" : "Atherosclerosis of native coronary artery of transplanted heart with unstable angina"
      },
      {
        "code" : "I25.751",
        "display" : "Atherosclerosis of native coronary artery of transplanted heart with angina pectoris with documented spasm"
      },
      {
        "code" : "I25.752",
        "display" : "Atherosclerosis of native coronary artery of transplanted heart with refractory angina pectoris"
      },
      {
        "code" : "I25.758",
        "display" : "Atherosclerosis of native coronary artery of transplanted heart with other forms of angina pectoris"
      },
      {
        "code" : "I25.759",
        "display" : "Atherosclerosis of native coronary artery of transplanted heart with unspecified angina pectoris"
      },
      {
        "code" : "I25.760",
        "display" : "Atherosclerosis of bypass graft of coronary artery of transplanted heart with unstable angina"
      },
      {
        "code" : "I25.761",
        "display" : "Atherosclerosis of bypass graft of coronary artery of transplanted heart with angina pectoris with documented spasm"
      },
      {
        "code" : "I25.762",
        "display" : "Atherosclerosis of bypass graft of coronary artery of transplanted heart with refractory angina pectoris"
      },
      {
        "code" : "I25.768",
        "display" : "Atherosclerosis of bypass graft of coronary artery of transplanted heart with other forms of angina pectoris"
      },
      {
        "code" : "I25.769",
        "display" : "Atherosclerosis of bypass graft of coronary artery of transplanted heart with unspecified angina pectoris"
      },
      {
        "code" : "I25.790",
        "display" : "Atherosclerosis of other coronary artery bypass graft(s) with unstable angina pectoris"
      },
      {
        "code" : "I25.791",
        "display" : "Atherosclerosis of other coronary artery bypass graft(s) with angina pectoris with documented spasm"
      },
      {
        "code" : "I25.792",
        "display" : "Atherosclerosis of other coronary artery bypass graft(s) with refractory angina pectoris"
      },
      {
        "code" : "I25.798",
        "display" : "Atherosclerosis of other coronary artery bypass graft(s) with other forms of angina pectoris"
      },
      {
        "code" : "I25.799",
        "display" : "Atherosclerosis of other coronary artery bypass graft(s) with unspecified angina pectoris"
      },
      {
        "code" : "I25.810",
        "display" : "Atherosclerosis of coronary artery bypass graft(s) without angina pectoris"
      },
      {
        "code" : "I25.811",
        "display" : "Atherosclerosis of native coronary artery of transplanted heart without angina pectoris"
      },
      {
        "code" : "I25.812",
        "display" : "Atherosclerosis of bypass graft of coronary artery of transplanted heart without angina pectoris"
      },
      {
        "code" : "I25.82",
        "display" : "Chronic total occlusion of coronary artery"
      },
      {
        "code" : "I25.83",
        "display" : "Coronary atherosclerosis due to lipid rich plaque"
      },
      {
        "code" : "I25.84",
        "display" : "Coronary atherosclerosis due to calcified coronary lesion"
      },
      {
        "code" : "I25.85",
        "display" : "Chronic coronary microvascular dysfunction"
      },
      {
        "code" : "I25.89",
        "display" : "Other forms of chronic ischemic heart disease"
      },
      {
        "code" : "I25.9",
        "display" : "Chronic ischemic heart disease, unspecified"
      },
      {
        "code" : "I69.30",
        "display" : "Unspecified sequelae of cerebral infarction"
      },
      {
        "code" : "I69.310",
        "display" : "Attention and concentration deficit following cerebral infarction"
      },
      {
        "code" : "I69.311",
        "display" : "Memory deficit following cerebral infarction"
      },
      {
        "code" : "I69.312",
        "display" : "Visuospatial deficit and spatial neglect following cerebral infarction"
      },
      {
        "code" : "I69.313",
        "display" : "Psychomotor deficit following cerebral infarction"
      },
      {
        "code" : "I69.314",
        "display" : "Frontal lobe and executive function deficit following cerebral infarction"
      },
      {
        "code" : "I69.315",
        "display" : "Cognitive social or emotional deficit following cerebral infarction"
      },
      {
        "code" : "I69.318",
        "display" : "Other symptoms and signs involving cognitive functions following cerebral infarction"
      },
      {
        "code" : "I69.319",
        "display" : "Unspecified symptoms and signs involving cognitive functions following cerebral infarction"
      },
      {
        "code" : "I69.320",
        "display" : "Aphasia following cerebral infarction"
      },
      {
        "code" : "I69.321",
        "display" : "Dysphasia following cerebral infarction"
      },
      {
        "code" : "I69.322",
        "display" : "Dysarthria following cerebral infarction"
      },
      {
        "code" : "I69.323",
        "display" : "Fluency disorder following cerebral infarction"
      },
      {
        "code" : "I69.328",
        "display" : "Other speech and language deficits following cerebral infarction"
      },
      {
        "code" : "I69.331",
        "display" : "Monoplegia of upper limb following cerebral infarction affecting right dominant side"
      },
      {
        "code" : "I69.332",
        "display" : "Monoplegia of upper limb following cerebral infarction affecting left dominant side"
      },
      {
        "code" : "I69.333",
        "display" : "Monoplegia of upper limb following cerebral infarction affecting right non-dominant side"
      },
      {
        "code" : "I69.334",
        "display" : "Monoplegia of upper limb following cerebral infarction affecting left non-dominant side"
      },
      {
        "code" : "I69.339",
        "display" : "Monoplegia of upper limb following cerebral infarction affecting unspecified side"
      },
      {
        "code" : "I69.341",
        "display" : "Monoplegia of lower limb following cerebral infarction affecting right dominant side"
      },
      {
        "code" : "I69.342",
        "display" : "Monoplegia of lower limb following cerebral infarction affecting left dominant side"
      },
      {
        "code" : "I69.343",
        "display" : "Monoplegia of lower limb following cerebral infarction affecting right non-dominant side"
      },
      {
        "code" : "I69.344",
        "display" : "Monoplegia of lower limb following cerebral infarction affecting left non-dominant side"
      },
      {
        "code" : "I69.349",
        "display" : "Monoplegia of lower limb following cerebral infarction affecting unspecified side"
      },
      {
        "code" : "I69.351",
        "display" : "Hemiplegia and hemiparesis following cerebral infarction affecting right dominant side"
      },
      {
        "code" : "I69.352",
        "display" : "Hemiplegia and hemiparesis following cerebral infarction affecting left dominant side"
      },
      {
        "code" : "I69.353",
        "display" : "Hemiplegia and hemiparesis following cerebral infarction affecting right non-dominant side"
      },
      {
        "code" : "I69.354",
        "display" : "Hemiplegia and hemiparesis following cerebral infarction affecting left non-dominant side"
      },
      {
        "code" : "I69.359",
        "display" : "Hemiplegia and hemiparesis following cerebral infarction affecting unspecified side"
      },
      {
        "code" : "I69.361",
        "display" : "Other paralytic syndrome following cerebral infarction affecting right dominant side"
      },
      {
        "code" : "I69.362",
        "display" : "Other paralytic syndrome following cerebral infarction affecting left dominant side"
      },
      {
        "code" : "I69.363",
        "display" : "Other paralytic syndrome following cerebral infarction affecting right non-dominant side"
      },
      {
        "code" : "I69.364",
        "display" : "Other paralytic syndrome following cerebral infarction affecting left non-dominant side"
      },
      {
        "code" : "I69.365",
        "display" : "Other paralytic syndrome following cerebral infarction, bilateral"
      },
      {
        "code" : "I69.369",
        "display" : "Other paralytic syndrome following cerebral infarction affecting unspecified side"
      },
      {
        "code" : "I69.390",
        "display" : "Apraxia following cerebral infarction"
      },
      {
        "code" : "I69.391",
        "display" : "Dysphagia following cerebral infarction"
      },
      {
        "code" : "I69.392",
        "display" : "Facial weakness following cerebral infarction"
      },
      {
        "code" : "I69.393",
        "display" : "Ataxia following cerebral infarction"
      },
      {
        "code" : "I69.398",
        "display" : "Other sequelae of cerebral infarction"
      },
      {
        "code" : "I70.0",
        "display" : "Atherosclerosis of aorta"
      },
      {
        "code" : "I70.1",
        "display" : "Atherosclerosis of renal artery"
      },
      {
        "code" : "I70.201",
        "display" : "Unspecified atherosclerosis of native arteries of extremities, right leg"
      },
      {
        "code" : "I70.202",
        "display" : "Unspecified atherosclerosis of native arteries of extremities, left leg"
      },
      {
        "code" : "I70.203",
        "display" : "Unspecified atherosclerosis of native arteries of extremities, bilateral legs"
      },
      {
        "code" : "I70.208",
        "display" : "Unspecified atherosclerosis of native arteries of extremities, other extremity"
      },
      {
        "code" : "I70.209",
        "display" : "Unspecified atherosclerosis of native arteries of extremities, unspecified extremity"
      },
      {
        "code" : "I70.211",
        "display" : "Atherosclerosis of native arteries of extremities with intermittent claudication, right leg"
      },
      {
        "code" : "I70.212",
        "display" : "Atherosclerosis of native arteries of extremities with intermittent claudication, left leg"
      },
      {
        "code" : "I70.213",
        "display" : "Atherosclerosis of native arteries of extremities with intermittent claudication, bilateral legs"
      },
      {
        "code" : "I70.218",
        "display" : "Atherosclerosis of native arteries of extremities with intermittent claudication, other extremity"
      },
      {
        "code" : "I70.219",
        "display" : "Atherosclerosis of native arteries of extremities with intermittent claudication, unspecified extremity"
      },
      {
        "code" : "I70.221",
        "display" : "Atherosclerosis of native arteries of extremities with rest pain, right leg"
      },
      {
        "code" : "I70.222",
        "display" : "Atherosclerosis of native arteries of extremities with rest pain, left leg"
      },
      {
        "code" : "I70.223",
        "display" : "Atherosclerosis of native arteries of extremities with rest pain, bilateral legs"
      },
      {
        "code" : "I70.228",
        "display" : "Atherosclerosis of native arteries of extremities with rest pain, other extremity"
      },
      {
        "code" : "I70.229",
        "display" : "Atherosclerosis of native arteries of extremities with rest pain, unspecified extremity"
      },
      {
        "code" : "I70.231",
        "display" : "Atherosclerosis of native arteries of right leg with ulceration of thigh"
      },
      {
        "code" : "I70.232",
        "display" : "Atherosclerosis of native arteries of right leg with ulceration of calf"
      },
      {
        "code" : "I70.233",
        "display" : "Atherosclerosis of native arteries of right leg with ulceration of ankle"
      },
      {
        "code" : "I70.234",
        "display" : "Atherosclerosis of native arteries of right leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.235",
        "display" : "Atherosclerosis of native arteries of right leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.238",
        "display" : "Atherosclerosis of native arteries of right leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.239",
        "display" : "Atherosclerosis of native arteries of right leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.241",
        "display" : "Atherosclerosis of native arteries of left leg with ulceration of thigh"
      },
      {
        "code" : "I70.242",
        "display" : "Atherosclerosis of native arteries of left leg with ulceration of calf"
      },
      {
        "code" : "I70.243",
        "display" : "Atherosclerosis of native arteries of left leg with ulceration of ankle"
      },
      {
        "code" : "I70.244",
        "display" : "Atherosclerosis of native arteries of left leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.245",
        "display" : "Atherosclerosis of native arteries of left leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.248",
        "display" : "Atherosclerosis of native arteries of left leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.249",
        "display" : "Atherosclerosis of native arteries of left leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.25",
        "display" : "Atherosclerosis of native arteries of other extremities with ulceration"
      },
      {
        "code" : "I70.261",
        "display" : "Atherosclerosis of native arteries of extremities with gangrene, right leg"
      },
      {
        "code" : "I70.262",
        "display" : "Atherosclerosis of native arteries of extremities with gangrene, left leg"
      },
      {
        "code" : "I70.263",
        "display" : "Atherosclerosis of native arteries of extremities with gangrene, bilateral legs"
      },
      {
        "code" : "I70.268",
        "display" : "Atherosclerosis of native arteries of extremities with gangrene, other extremity"
      },
      {
        "code" : "I70.269",
        "display" : "Atherosclerosis of native arteries of extremities with gangrene, unspecified extremity"
      },
      {
        "code" : "I70.291",
        "display" : "Other atherosclerosis of native arteries of extremities, right leg"
      },
      {
        "code" : "I70.292",
        "display" : "Other atherosclerosis of native arteries of extremities, left leg"
      },
      {
        "code" : "I70.293",
        "display" : "Other atherosclerosis of native arteries of extremities, bilateral legs"
      },
      {
        "code" : "I70.298",
        "display" : "Other atherosclerosis of native arteries of extremities, other extremity"
      },
      {
        "code" : "I70.299",
        "display" : "Other atherosclerosis of native arteries of extremities, unspecified extremity"
      },
      {
        "code" : "I70.301",
        "display" : "Unspecified atherosclerosis of unspecified type of bypass graft(s) of the extremities, right leg"
      },
      {
        "code" : "I70.302",
        "display" : "Unspecified atherosclerosis of unspecified type of bypass graft(s) of the extremities, left leg"
      },
      {
        "code" : "I70.303",
        "display" : "Unspecified atherosclerosis of unspecified type of bypass graft(s) of the extremities, bilateral legs"
      },
      {
        "code" : "I70.308",
        "display" : "Unspecified atherosclerosis of unspecified type of bypass graft(s) of the extremities, other extremity"
      },
      {
        "code" : "I70.309",
        "display" : "Unspecified atherosclerosis of unspecified type of bypass graft(s) of the extremities, unspecified extremity"
      },
      {
        "code" : "I70.311",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with intermittent claudication, right leg"
      },
      {
        "code" : "I70.312",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with intermittent claudication, left leg"
      },
      {
        "code" : "I70.313",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with intermittent claudication, bilateral legs"
      },
      {
        "code" : "I70.318",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with intermittent claudication, other extremity"
      },
      {
        "code" : "I70.319",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with intermittent claudication, unspecified extremity"
      },
      {
        "code" : "I70.321",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with rest pain, right leg"
      },
      {
        "code" : "I70.322",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with rest pain, left leg"
      },
      {
        "code" : "I70.323",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with rest pain, bilateral legs"
      },
      {
        "code" : "I70.328",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with rest pain, other extremity"
      },
      {
        "code" : "I70.329",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with rest pain, unspecified extremity"
      },
      {
        "code" : "I70.331",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the right leg with ulceration of thigh"
      },
      {
        "code" : "I70.332",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the right leg with ulceration of calf"
      },
      {
        "code" : "I70.333",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the right leg with ulceration of ankle"
      },
      {
        "code" : "I70.334",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the right leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.335",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the right leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.338",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the right leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.339",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the right leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.341",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the left leg with ulceration of thigh"
      },
      {
        "code" : "I70.342",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the left leg with ulceration of calf"
      },
      {
        "code" : "I70.343",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the left leg with ulceration of ankle"
      },
      {
        "code" : "I70.344",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the left leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.345",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the left leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.348",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the left leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.349",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the left leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.35",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of other extremity with ulceration"
      },
      {
        "code" : "I70.361",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with gangrene, right leg"
      },
      {
        "code" : "I70.362",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with gangrene, left leg"
      },
      {
        "code" : "I70.363",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with gangrene, bilateral legs"
      },
      {
        "code" : "I70.368",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with gangrene, other extremity"
      },
      {
        "code" : "I70.369",
        "display" : "Atherosclerosis of unspecified type of bypass graft(s) of the extremities with gangrene, unspecified extremity"
      },
      {
        "code" : "I70.391",
        "display" : "Other atherosclerosis of unspecified type of bypass graft(s) of the extremities, right leg"
      },
      {
        "code" : "I70.392",
        "display" : "Other atherosclerosis of unspecified type of bypass graft(s) of the extremities, left leg"
      },
      {
        "code" : "I70.393",
        "display" : "Other atherosclerosis of unspecified type of bypass graft(s) of the extremities, bilateral legs"
      },
      {
        "code" : "I70.398",
        "display" : "Other atherosclerosis of unspecified type of bypass graft(s) of the extremities, other extremity"
      },
      {
        "code" : "I70.399",
        "display" : "Other atherosclerosis of unspecified type of bypass graft(s) of the extremities, unspecified extremity"
      },
      {
        "code" : "I70.401",
        "display" : "Unspecified atherosclerosis of autologous vein bypass graft(s) of the extremities, right leg"
      },
      {
        "code" : "I70.402",
        "display" : "Unspecified atherosclerosis of autologous vein bypass graft(s) of the extremities, left leg"
      },
      {
        "code" : "I70.403",
        "display" : "Unspecified atherosclerosis of autologous vein bypass graft(s) of the extremities, bilateral legs"
      },
      {
        "code" : "I70.408",
        "display" : "Unspecified atherosclerosis of autologous vein bypass graft(s) of the extremities, other extremity"
      },
      {
        "code" : "I70.409",
        "display" : "Unspecified atherosclerosis of autologous vein bypass graft(s) of the extremities, unspecified extremity"
      },
      {
        "code" : "I70.411",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with intermittent claudication, right leg"
      },
      {
        "code" : "I70.412",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with intermittent claudication, left leg"
      },
      {
        "code" : "I70.413",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with intermittent claudication, bilateral legs"
      },
      {
        "code" : "I70.418",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with intermittent claudication, other extremity"
      },
      {
        "code" : "I70.419",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with intermittent claudication, unspecified extremity"
      },
      {
        "code" : "I70.421",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with rest pain, right leg"
      },
      {
        "code" : "I70.422",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with rest pain, left leg"
      },
      {
        "code" : "I70.423",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with rest pain, bilateral legs"
      },
      {
        "code" : "I70.428",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with rest pain, other extremity"
      },
      {
        "code" : "I70.429",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with rest pain, unspecified extremity"
      },
      {
        "code" : "I70.431",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the right leg with ulceration of thigh"
      },
      {
        "code" : "I70.432",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the right leg with ulceration of calf"
      },
      {
        "code" : "I70.433",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the right leg with ulceration of ankle"
      },
      {
        "code" : "I70.434",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the right leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.435",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the right leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.438",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the right leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.439",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the right leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.441",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the left leg with ulceration of thigh"
      },
      {
        "code" : "I70.442",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the left leg with ulceration of calf"
      },
      {
        "code" : "I70.443",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the left leg with ulceration of ankle"
      },
      {
        "code" : "I70.444",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the left leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.445",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the left leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.448",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the left leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.449",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the left leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.45",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of other extremity with ulceration"
      },
      {
        "code" : "I70.461",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with gangrene, right leg"
      },
      {
        "code" : "I70.462",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with gangrene, left leg"
      },
      {
        "code" : "I70.463",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with gangrene, bilateral legs"
      },
      {
        "code" : "I70.468",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with gangrene, other extremity"
      },
      {
        "code" : "I70.469",
        "display" : "Atherosclerosis of autologous vein bypass graft(s) of the extremities with gangrene, unspecified extremity"
      },
      {
        "code" : "I70.491",
        "display" : "Other atherosclerosis of autologous vein bypass graft(s) of the extremities, right leg"
      },
      {
        "code" : "I70.492",
        "display" : "Other atherosclerosis of autologous vein bypass graft(s) of the extremities, left leg"
      },
      {
        "code" : "I70.493",
        "display" : "Other atherosclerosis of autologous vein bypass graft(s) of the extremities, bilateral legs"
      },
      {
        "code" : "I70.498",
        "display" : "Other atherosclerosis of autologous vein bypass graft(s) of the extremities, other extremity"
      },
      {
        "code" : "I70.499",
        "display" : "Other atherosclerosis of autologous vein bypass graft(s) of the extremities, unspecified extremity"
      },
      {
        "code" : "I70.501",
        "display" : "Unspecified atherosclerosis of nonautologous biological bypass graft(s) of the extremities, right leg"
      },
      {
        "code" : "I70.502",
        "display" : "Unspecified atherosclerosis of nonautologous biological bypass graft(s) of the extremities, left leg"
      },
      {
        "code" : "I70.503",
        "display" : "Unspecified atherosclerosis of nonautologous biological bypass graft(s) of the extremities, bilateral legs"
      },
      {
        "code" : "I70.508",
        "display" : "Unspecified atherosclerosis of nonautologous biological bypass graft(s) of the extremities, other extremity"
      },
      {
        "code" : "I70.509",
        "display" : "Unspecified atherosclerosis of nonautologous biological bypass graft(s) of the extremities, unspecified extremity"
      },
      {
        "code" : "I70.511",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with intermittent claudication, right leg"
      },
      {
        "code" : "I70.512",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with intermittent claudication, left leg"
      },
      {
        "code" : "I70.513",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with intermittent claudication, bilateral legs"
      },
      {
        "code" : "I70.518",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with intermittent claudication, other extremity"
      },
      {
        "code" : "I70.519",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with intermittent claudication, unspecified extremity"
      },
      {
        "code" : "I70.521",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with rest pain, right leg"
      },
      {
        "code" : "I70.522",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with rest pain, left leg"
      },
      {
        "code" : "I70.523",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with rest pain, bilateral legs"
      },
      {
        "code" : "I70.528",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with rest pain, other extremity"
      },
      {
        "code" : "I70.529",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with rest pain, unspecified extremity"
      },
      {
        "code" : "I70.531",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the right leg with ulceration of thigh"
      },
      {
        "code" : "I70.532",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the right leg with ulceration of calf"
      },
      {
        "code" : "I70.533",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the right leg with ulceration of ankle"
      },
      {
        "code" : "I70.534",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the right leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.535",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the right leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.538",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the right leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.539",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the right leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.541",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the left leg with ulceration of thigh"
      },
      {
        "code" : "I70.542",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the left leg with ulceration of calf"
      },
      {
        "code" : "I70.543",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the left leg with ulceration of ankle"
      },
      {
        "code" : "I70.544",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the left leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.545",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the left leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.548",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the left leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.549",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the left leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.55",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of other extremity with ulceration"
      },
      {
        "code" : "I70.561",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with gangrene, right leg"
      },
      {
        "code" : "I70.562",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with gangrene, left leg"
      },
      {
        "code" : "I70.563",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with gangrene, bilateral legs"
      },
      {
        "code" : "I70.568",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with gangrene, other extremity"
      },
      {
        "code" : "I70.569",
        "display" : "Atherosclerosis of nonautologous biological bypass graft(s) of the extremities with gangrene, unspecified extremity"
      },
      {
        "code" : "I70.591",
        "display" : "Other atherosclerosis of nonautologous biological bypass graft(s) of the extremities, right leg"
      },
      {
        "code" : "I70.592",
        "display" : "Other atherosclerosis of nonautologous biological bypass graft(s) of the extremities, left leg"
      },
      {
        "code" : "I70.593",
        "display" : "Other atherosclerosis of nonautologous biological bypass graft(s) of the extremities, bilateral legs"
      },
      {
        "code" : "I70.598",
        "display" : "Other atherosclerosis of nonautologous biological bypass graft(s) of the extremities, other extremity"
      },
      {
        "code" : "I70.599",
        "display" : "Other atherosclerosis of nonautologous biological bypass graft(s) of the extremities, unspecified extremity"
      },
      {
        "code" : "I70.601",
        "display" : "Unspecified atherosclerosis of nonbiological bypass graft(s) of the extremities, right leg"
      },
      {
        "code" : "I70.602",
        "display" : "Unspecified atherosclerosis of nonbiological bypass graft(s) of the extremities, left leg"
      },
      {
        "code" : "I70.603",
        "display" : "Unspecified atherosclerosis of nonbiological bypass graft(s) of the extremities, bilateral legs"
      },
      {
        "code" : "I70.608",
        "display" : "Unspecified atherosclerosis of nonbiological bypass graft(s) of the extremities, other extremity"
      },
      {
        "code" : "I70.609",
        "display" : "Unspecified atherosclerosis of nonbiological bypass graft(s) of the extremities, unspecified extremity"
      },
      {
        "code" : "I70.611",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with intermittent claudication, right leg"
      },
      {
        "code" : "I70.612",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with intermittent claudication, left leg"
      },
      {
        "code" : "I70.613",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with intermittent claudication, bilateral legs"
      },
      {
        "code" : "I70.618",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with intermittent claudication, other extremity"
      },
      {
        "code" : "I70.619",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with intermittent claudication, unspecified extremity"
      },
      {
        "code" : "I70.621",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with rest pain, right leg"
      },
      {
        "code" : "I70.622",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with rest pain, left leg"
      },
      {
        "code" : "I70.623",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with rest pain, bilateral legs"
      },
      {
        "code" : "I70.628",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with rest pain, other extremity"
      },
      {
        "code" : "I70.629",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with rest pain, unspecified extremity"
      },
      {
        "code" : "I70.631",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the right leg with ulceration of thigh"
      },
      {
        "code" : "I70.632",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the right leg with ulceration of calf"
      },
      {
        "code" : "I70.633",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the right leg with ulceration of ankle"
      },
      {
        "code" : "I70.634",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the right leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.635",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the right leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.638",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the right leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.639",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the right leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.641",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the left leg with ulceration of thigh"
      },
      {
        "code" : "I70.642",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the left leg with ulceration of calf"
      },
      {
        "code" : "I70.643",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the left leg with ulceration of ankle"
      },
      {
        "code" : "I70.644",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the left leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.645",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the left leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.648",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the left leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.649",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the left leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.65",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of other extremity with ulceration"
      },
      {
        "code" : "I70.661",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with gangrene, right leg"
      },
      {
        "code" : "I70.662",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with gangrene, left leg"
      },
      {
        "code" : "I70.663",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with gangrene, bilateral legs"
      },
      {
        "code" : "I70.668",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with gangrene, other extremity"
      },
      {
        "code" : "I70.669",
        "display" : "Atherosclerosis of nonbiological bypass graft(s) of the extremities with gangrene, unspecified extremity"
      },
      {
        "code" : "I70.691",
        "display" : "Other atherosclerosis of nonbiological bypass graft(s) of the extremities, right leg"
      },
      {
        "code" : "I70.692",
        "display" : "Other atherosclerosis of nonbiological bypass graft(s) of the extremities, left leg"
      },
      {
        "code" : "I70.693",
        "display" : "Other atherosclerosis of nonbiological bypass graft(s) of the extremities, bilateral legs"
      },
      {
        "code" : "I70.698",
        "display" : "Other atherosclerosis of nonbiological bypass graft(s) of the extremities, other extremity"
      },
      {
        "code" : "I70.699",
        "display" : "Other atherosclerosis of nonbiological bypass graft(s) of the extremities, unspecified extremity"
      },
      {
        "code" : "I70.701",
        "display" : "Unspecified atherosclerosis of other type of bypass graft(s) of the extremities, right leg"
      },
      {
        "code" : "I70.702",
        "display" : "Unspecified atherosclerosis of other type of bypass graft(s) of the extremities, left leg"
      },
      {
        "code" : "I70.703",
        "display" : "Unspecified atherosclerosis of other type of bypass graft(s) of the extremities, bilateral legs"
      },
      {
        "code" : "I70.708",
        "display" : "Unspecified atherosclerosis of other type of bypass graft(s) of the extremities, other extremity"
      },
      {
        "code" : "I70.709",
        "display" : "Unspecified atherosclerosis of other type of bypass graft(s) of the extremities, unspecified extremity"
      },
      {
        "code" : "I70.711",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with intermittent claudication, right leg"
      },
      {
        "code" : "I70.712",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with intermittent claudication, left leg"
      },
      {
        "code" : "I70.713",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with intermittent claudication, bilateral legs"
      },
      {
        "code" : "I70.718",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with intermittent claudication, other extremity"
      },
      {
        "code" : "I70.719",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with intermittent claudication, unspecified extremity"
      },
      {
        "code" : "I70.721",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with rest pain, right leg"
      },
      {
        "code" : "I70.722",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with rest pain, left leg"
      },
      {
        "code" : "I70.723",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with rest pain, bilateral legs"
      },
      {
        "code" : "I70.728",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with rest pain, other extremity"
      },
      {
        "code" : "I70.729",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with rest pain, unspecified extremity"
      },
      {
        "code" : "I70.731",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the right leg with ulceration of thigh"
      },
      {
        "code" : "I70.732",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the right leg with ulceration of calf"
      },
      {
        "code" : "I70.733",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the right leg with ulceration of ankle"
      },
      {
        "code" : "I70.734",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the right leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.735",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the right leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.738",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the right leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.739",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the right leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.741",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the left leg with ulceration of thigh"
      },
      {
        "code" : "I70.742",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the left leg with ulceration of calf"
      },
      {
        "code" : "I70.743",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the left leg with ulceration of ankle"
      },
      {
        "code" : "I70.744",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the left leg with ulceration of heel and midfoot"
      },
      {
        "code" : "I70.745",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the left leg with ulceration of other part of foot"
      },
      {
        "code" : "I70.748",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the left leg with ulceration of other part of lower leg"
      },
      {
        "code" : "I70.749",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the left leg with ulceration of unspecified site"
      },
      {
        "code" : "I70.75",
        "display" : "Atherosclerosis of other type of bypass graft(s) of other extremity with ulceration"
      },
      {
        "code" : "I70.761",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with gangrene, right leg"
      },
      {
        "code" : "I70.762",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with gangrene, left leg"
      },
      {
        "code" : "I70.763",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with gangrene, bilateral legs"
      },
      {
        "code" : "I70.768",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with gangrene, other extremity"
      },
      {
        "code" : "I70.769",
        "display" : "Atherosclerosis of other type of bypass graft(s) of the extremities with gangrene, unspecified extremity"
      },
      {
        "code" : "I70.791",
        "display" : "Other atherosclerosis of other type of bypass graft(s) of the extremities, right leg"
      },
      {
        "code" : "I70.792",
        "display" : "Other atherosclerosis of other type of bypass graft(s) of the extremities, left leg"
      },
      {
        "code" : "I70.793",
        "display" : "Other atherosclerosis of other type of bypass graft(s) of the extremities, bilateral legs"
      },
      {
        "code" : "I70.798",
        "display" : "Other atherosclerosis of other type of bypass graft(s) of the extremities, other extremity"
      },
      {
        "code" : "I70.799",
        "display" : "Other atherosclerosis of other type of bypass graft(s) of the extremities, unspecified extremity"
      },
      {
        "code" : "I70.8",
        "display" : "Atherosclerosis of other arteries"
      },
      {
        "code" : "I70.90",
        "display" : "Unspecified atherosclerosis"
      },
      {
        "code" : "I70.91",
        "display" : "Generalized atherosclerosis"
      },
      {
        "code" : "I70.92",
        "display" : "Chronic total occlusion of artery of the extremities"
      },
      {
        "code" : "N18.30",
        "display" : "Chronic kidney disease, stage 3 unspecified"
      },
      {
        "code" : "N18.31",
        "display" : "Chronic kidney disease, stage 3a"
      },
      {
        "code" : "N18.32",
        "display" : "Chronic kidney disease, stage 3b"
      }]
    }]
  }
}

```
