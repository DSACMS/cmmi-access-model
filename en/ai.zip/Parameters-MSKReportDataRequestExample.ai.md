# MSK Report Data Request Example - CMS ACCESS Model API v0.9.12

## Example Parameters: MSK Report Data Request Example



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "MSKReportDataRequestExample",
  "meta" : {
    "profile" : ["https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-in"]
  },
  "parameter" : [{
    "name" : "participantID",
    "valueIdentifier" : {
      "system" : "https://dsacms.github.io/cmmi-access-model/participant-id",
      "value" : "ACCES12345"
    }
  },
  {
    "name" : "payerID",
    "valueIdentifier" : {
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/us/carin-bb/CodeSystem/C4BBIdentifierType",
          "code" : "payerid",
          "display" : "Payer ID"
        }]
      },
      "system" : "urn:oid:2.16.840.1.113883.3.221.5",
      "value" : "12345"
    }
  },
  {
    "name" : "track",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://dsacms.github.io/cmmi-access-model/CodeSystem/ACCESSTrackCS",
        "code" : "MSK",
        "display" : "Musculoskeletal track"
      }]
    }
  },
  {
    "name" : "reportType",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://dsacms.github.io/cmmi-access-model/CodeSystem/ACCESSReportTypeCS",
        "code" : "quarterly",
        "display" : "Quarterly Data Report"
      }]
    }
  },
  {
    "name" : "dataBundle",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "MSKReportDataBundleExample",
      "meta" : {
        "profile" : ["https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-data-reporting-bundle"]
      },
      "identifier" : {
        "system" : "http://example.org/data-bundle-id",
        "value" : "bundle-msk-001"
      },
      "type" : "document",
      "timestamp" : "2026-01-26T12:00:00Z",
      "entry" : [{
        "fullUrl" : "http://example.org/Composition/MSKReportDataCompositionExample",
        "resource" : {
          "resourceType" : "Composition",
          "id" : "MSKReportDataCompositionExample",
          "meta" : {
            "profile" : ["https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-data-reporting-composition"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><h3>ACCESS MSK Track Data Report</h3><p>Patient: John Doe (MBI: 1EG4TE5MK73)</p><p>Report Date: 2026-01-26</p><p>Author: Jane Smith</p></div>"
          },
          "status" : "final",
          "type" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "74465-6",
              "display" : "Questionnaire response Document"
            }]
          },
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "date" : "2026-01-26T12:00:00Z",
          "author" : [{
            "reference" : "Practitioner/PractitionerExample"
          }],
          "title" : "ACCESS MSK Track Data Report",
          "custodian" : {
            "reference" : "Organization/OrganizationExample"
          },
          "section" : [{
            "title" : "Data reporting for MSK track",
            "code" : {
              "coding" : [{
                "system" : "https://dsacms.github.io/cmmi-access-model/CodeSystem/ACCESSTrackCS",
                "code" : "MSK"
              }]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>Musculoskeletal Track Data Reporting including pain assessments and patient-reported outcomes.</p></div>"
            },
            "section" : [{
              "title" : "PROMIS Physical Function Short Form 6b",
              "code" : {
                "coding" : [{
                  "system" : "http://loinc.org",
                  "code" : "76804-4"
                }]
              },
              "entry" : [{
                "reference" : "QuestionnaireResponse/PROMISPhysicalFunctionExample"
              }]
            },
            {
              "title" : "PROMIS Physical Function CAT",
              "code" : {
                "coding" : [{
                  "system" : "http://loinc.org",
                  "code" : "91722-9"
                }]
              },
              "entry" : [{
                "reference" : "QuestionnaireResponse/PROMISPhysicalFunctionCATExample"
              }]
            },
            {
              "title" : "PROMIS Pain Interference Short Form 6a",
              "code" : {
                "coding" : [{
                  "system" : "http://loinc.org",
                  "code" : "90973-9"
                }]
              },
              "entry" : [{
                "reference" : "QuestionnaireResponse/PROMISPainInterferenceSFExample"
              }]
            },
            {
              "title" : "PROMIS Pain Interference CAT",
              "code" : {
                "coding" : [{
                  "system" : "http://loinc.org",
                  "code" : "89923-7"
                }]
              },
              "entry" : [{
                "reference" : "QuestionnaireResponse/PROMISPainInterferenceCATExample"
              }]
            },
            {
              "title" : "Oswestry Disability Index",
              "code" : {
                "coding" : [{
                  "system" : "http://loinc.org",
                  "code" : "97908-8"
                }]
              },
              "entry" : [{
                "reference" : "QuestionnaireResponse/OswestryDisabilityIndexExample"
              }]
            },
            {
              "title" : "Neck Disability Index",
              "code" : {
                "coding" : [{
                  "system" : "http://loinc.org",
                  "code" : "82226-2"
                }]
              },
              "entry" : [{
                "reference" : "QuestionnaireResponse/NeckDisabilityIndexExample"
              }]
            },
            {
              "title" : "QuickDASH",
              "code" : {
                "coding" : [{
                  "system" : "https://dsacms.github.io/cmmi-access-model/CodeSystem/ACCESSReportDataCompositionSectionCS",
                  "code" : "QuickDASH"
                }]
              },
              "entry" : [{
                "reference" : "QuestionnaireResponse/QuickDASHExample"
              }]
            },
            {
              "title" : "Patient's Global Impression of Change",
              "code" : {
                "coding" : [{
                  "system" : "https://dsacms.github.io/cmmi-access-model/CodeSystem/ACCESSReportDataCompositionSectionCS",
                  "code" : "PGIC"
                }]
              },
              "entry" : [{
                "reference" : "QuestionnaireResponse/MSKPGICExample"
              }]
            },
            {
              "title" : "KOOS JR",
              "code" : {
                "coding" : [{
                  "system" : "http://loinc.org",
                  "code" : "82324-5"
                }]
              },
              "entry" : [{
                "reference" : "QuestionnaireResponse/KOOSJRExample"
              }]
            },
            {
              "title" : "HOOS JR",
              "code" : {
                "coding" : [{
                  "system" : "http://loinc.org",
                  "code" : "82316-1"
                }]
              },
              "entry" : [{
                "reference" : "QuestionnaireResponse/HOOSJRExample"
              }]
            },
            {
              "title" : "PROMIS Pain Intensity NRS",
              "code" : {
                "coding" : [{
                  "system" : "http://loinc.org",
                  "code" : "72514-3"
                }]
              },
              "entry" : [{
                "reference" : "QuestionnaireResponse/PROMISNRSExample"
              }]
            }]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/Patient/PatientExample",
        "resource" : {
          "resourceType" : "Patient",
          "id" : "PatientExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-patient|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\">Patient John Doe, male, born 1950-01-01, Medicare ID: 1EG4TE5MK73</div>"
          },
          "identifier" : [{
            "type" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                "code" : "MC"
              }]
            },
            "system" : "http://terminology.hl7.org/NamingSystem/cmsMBI",
            "value" : "1EG4TE5MK73"
          }],
          "name" : [{
            "family" : "Doe",
            "given" : ["John"]
          }],
          "gender" : "male",
          "birthDate" : "1950-01-01"
        }
      },
      {
        "fullUrl" : "http://example.org/Practitioner/PractitionerExample",
        "resource" : {
          "resourceType" : "Practitioner",
          "id" : "PractitionerExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-practitioner|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\">Practitioner Jane Smith, NPI: 1234567893</div>"
          },
          "identifier" : [{
            "system" : "http://hl7.org/fhir/sid/us-npi",
            "value" : "1234567893"
          }],
          "name" : [{
            "family" : "Smith",
            "given" : ["Jane"]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/Organization/OrganizationExample",
        "resource" : {
          "resourceType" : "Organization",
          "id" : "OrganizationExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-organization|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\">Example Healthcare Organization, ACCESS Participant ID: ACCES12345</div>"
          },
          "identifier" : [{
            "system" : "https://dsacms.github.io/cmmi-access-model/participant-id",
            "value" : "ACCES12345"
          }],
          "active" : true,
          "name" : "Example Healthcare Organization"
        }
      },
      {
        "fullUrl" : "http://example.org/QuestionnaireResponse/PROMISPhysicalFunctionExample",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "PROMISPhysicalFunctionExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>PROMIS Physical Function (Short Form 6b) QuestionnaireResponse for John Doe. T-score: 36.8.</p></div>"
          },
          "questionnaire" : "http://example.org/Questionnaire/PROMISPhysicalFunctionQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "authored" : "2026-01-15T10:30:00Z",
          "author" : {
            "reference" : "Patient/PatientExample"
          },
          "item" : [{
            "linkId" : "pf6b-1",
            "text" : "Are you able to do chores such as vacuuming or yard work?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 4
                }],
                "system" : "http://loinc.org",
                "code" : "LA13918-0",
                "display" : "With a little difficulty"
              }
            }]
          },
          {
            "linkId" : "pf6b-2",
            "text" : "Are you able to go up and down stairs at a normal pace?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "system" : "http://loinc.org",
                "code" : "LA13920-6",
                "display" : "With some difficulty"
              }
            }]
          },
          {
            "linkId" : "pf6b-3",
            "text" : "Are you able to go for a walk of at least 15 minutes?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "system" : "http://loinc.org",
                "code" : "LA13920-6",
                "display" : "With some difficulty"
              }
            }]
          },
          {
            "linkId" : "pf6b-4",
            "text" : "Are you able to run errands and shop?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 4
                }],
                "system" : "http://loinc.org",
                "code" : "LA13918-0",
                "display" : "With a little difficulty"
              }
            }]
          },
          {
            "linkId" : "pf6b-5",
            "text" : "Does your health now limit you in doing two hours of physical labor?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 1
                }],
                "system" : "http://loinc.org",
                "code" : "LA13868-7",
                "display" : "Cannot do"
              }
            }]
          },
          {
            "linkId" : "pf6b-6",
            "text" : "Does your health now limit you in doing moderate work around the house like vacuuming, sweeping floors or carrying in groceries?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA11911-7",
                "display" : "Quite a lot"
              }
            }]
          },
          {
            "linkId" : "raw_score",
            "answer" : [{
              "valueDecimal" : 17
            }]
          },
          {
            "linkId" : "tscore",
            "answer" : [{
              "valueDecimal" : 36.8
            }]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/QuestionnaireResponse/PROMISPhysicalFunctionCATExample",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "PROMISPhysicalFunctionCATExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>PROMIS Physical Function (CAT) QuestionnaireResponse for John Doe. T-score: 38.</p></div>"
          },
          "questionnaire" : "http://example.org/Questionnaire/PROMISPhysicalFunctionCATQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "authored" : "2026-01-15T10:30:00Z",
          "author" : {
            "reference" : "Patient/PatientExample"
          },
          "item" : [{
            "linkId" : "pf-cat-1",
            "text" : "Does your health now limit you in doing two hours of physical labor?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA11911-7",
                "display" : "Quite a lot"
              }
            }]
          },
          {
            "linkId" : "pf-cat-2",
            "text" : "Are you able to do chores such as vacuuming or yard work?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "system" : "http://loinc.org",
                "code" : "LA13920-6",
                "display" : "With some difficulty"
              }
            }]
          },
          {
            "linkId" : "pf-cat-3",
            "text" : "To what extent are you able to carry out your everyday physical activities such as walking, climbing stairs, carrying groceries, or moving a chair?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "system" : "http://loinc.org",
                "code" : "LA13939-6",
                "display" : "Moderately"
              }
            }]
          },
          {
            "linkId" : "pf-cat-4",
            "text" : "Does your health now limit you in walking more than a mile?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA11911-7",
                "display" : "Quite a lot"
              }
            }]
          },
          {
            "linkId" : "tscore",
            "answer" : [{
              "valueDecimal" : 38
            }]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/QuestionnaireResponse/PROMISPainInterferenceSFExample",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "PROMISPainInterferenceSFExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>PROMIS Pain Interference (Short Form 6a) QuestionnaireResponse for John Doe. T-score: 58.6.</p></div>"
          },
          "questionnaire" : "http://example.org/Questionnaire/PROMISPainInterferenceSFQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "authored" : "2026-01-15T10:30:00Z",
          "author" : {
            "reference" : "Patient/PatientExample"
          },
          "item" : [{
            "linkId" : "pi6a-1",
            "text" : "In the past 7 days: How much did pain interfere with your day to day activities?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA13863-8",
                "display" : "A little bit"
              }
            }]
          },
          {
            "linkId" : "pi6a-2",
            "text" : "In the past 7 days: How much did pain interfere with work around the home?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA13863-8",
                "display" : "A little bit"
              }
            }]
          },
          {
            "linkId" : "pi6a-3",
            "text" : "In the past 7 days: How much did pain interfere with your ability to participate in social activities?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "system" : "http://loinc.org",
                "code" : "LA13909-9",
                "display" : "Somewhat"
              }
            }]
          },
          {
            "linkId" : "pi6a-4",
            "text" : "In the past 7 days: How much did pain interfere with your household chores?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA13863-8",
                "display" : "A little bit"
              }
            }]
          },
          {
            "linkId" : "pi6a-5",
            "text" : "In the past 7 days: How much did pain interfere with the things you usually do for fun?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "system" : "http://loinc.org",
                "code" : "LA13909-9",
                "display" : "Somewhat"
              }
            }]
          },
          {
            "linkId" : "pi6a-6",
            "text" : "In the past 7 days: How much did pain interfere with your enjoyment of social activities?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "system" : "http://loinc.org",
                "code" : "LA13909-9",
                "display" : "Somewhat"
              }
            }]
          },
          {
            "linkId" : "raw_score",
            "answer" : [{
              "valueDecimal" : 15
            }]
          },
          {
            "linkId" : "tscore",
            "answer" : [{
              "valueDecimal" : 58.6
            }]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/QuestionnaireResponse/PROMISPainInterferenceCATExample",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "PROMISPainInterferenceCATExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>PROMIS Pain Interference (CAT) QuestionnaireResponse for John Doe. T-score: 70.</p></div>"
          },
          "questionnaire" : "http://example.org/Questionnaire/PROMISPainInterferenceCATQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "authored" : "2026-01-15T10:30:00Z",
          "author" : {
            "reference" : "Patient/PatientExample"
          },
          "item" : [{
            "linkId" : "pi-cat-1",
            "text" : "In the past 7 days: How much did pain interfere with your day to day activities?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 4
                }],
                "system" : "http://loinc.org",
                "code" : "LA13902-4",
                "display" : "Quite a bit"
              }
            }]
          },
          {
            "linkId" : "pi-cat-2",
            "text" : "In the past 7 days: How much did pain interfere with your ability to participate in social activities?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 5
                }],
                "system" : "http://loinc.org",
                "code" : "LA13914-9",
                "display" : "Very much"
              }
            }]
          },
          {
            "linkId" : "pi-cat-3",
            "text" : "In the past 7 days: How much did pain interfere with your enjoyment of social activities?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 4
                }],
                "system" : "http://loinc.org",
                "code" : "LA13902-4",
                "display" : "Quite a bit"
              }
            }]
          },
          {
            "linkId" : "pi-cat-4",
            "text" : "In the past 7 days: How much did pain interfere with work around the home?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 5
                }],
                "system" : "http://loinc.org",
                "code" : "LA13914-9",
                "display" : "Very much"
              }
            }]
          },
          {
            "linkId" : "tscore",
            "answer" : [{
              "valueDecimal" : 70
            }]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/QuestionnaireResponse/OswestryDisabilityIndexExample",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "OswestryDisabilityIndexExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>Oswestry Disability Index QuestionnaireResponse for John Doe. Score: 36.</p></div>"
          },
          "questionnaire" : "http://example.org/Questionnaire/OswestryDisabilityIndexQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "authored" : "2026-01-15T10:30:00Z",
          "author" : {
            "reference" : "Patient/PatientExample"
          },
          "item" : [{
            "linkId" : "odi-1",
            "text" : "Pain intensity",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "display" : "The pain is moderate at the moment."
              }
            }]
          },
          {
            "linkId" : "odi-2",
            "text" : "Personal care (washing, dressing, etc.)",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 1
                }],
                "display" : "I can look after myself normally but it is very painful."
              }
            }]
          },
          {
            "linkId" : "odi-3",
            "text" : "Lifting",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "display" : "Pain prevents me lifting heavy weights off the floor, but I can manage if they are conveniently placed e.g. on a table."
              }
            }]
          },
          {
            "linkId" : "odi-4",
            "text" : "Walking",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 1
                }],
                "display" : "Pain prevents me from walking more than one mile."
              }
            }]
          },
          {
            "linkId" : "odi-5",
            "text" : "Sitting",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "display" : "Pain prevents me from sitting for more than one hour."
              }
            }]
          },
          {
            "linkId" : "odi-6",
            "text" : "Standing",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "display" : "Pain prevents me from standing for more than 1 hour."
              }
            }]
          },
          {
            "linkId" : "odi-7",
            "text" : "Sleeping",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 1
                }],
                "display" : "My sleep is occasionally interrupted by pain."
              }
            }]
          },
          {
            "linkId" : "odi-8",
            "text" : "Sex life (if applicable)",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "display" : "My sex life is nearly normal but is very painful."
              }
            }]
          },
          {
            "linkId" : "odi-9",
            "text" : "Social life",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "display" : "Pain has restricted my social life and I do not go out as often."
              }
            }]
          },
          {
            "linkId" : "odi-10",
            "text" : "Traveling",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "display" : "Pain is bad but I am able to manage trips over two hours."
              }
            }]
          },
          {
            "linkId" : "score",
            "answer" : [{
              "valueDecimal" : 38
            }]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/QuestionnaireResponse/NeckDisabilityIndexExample",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "NeckDisabilityIndexExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>Neck Disability Index QuestionnaireResponse for John Doe. Total score: 40.</p></div>"
          },
          "questionnaire" : "http://example.org/Questionnaire/NeckDisabilityIndexQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "authored" : "2026-01-15T10:30:00Z",
          "author" : {
            "reference" : "Patient/PatientExample"
          },
          "item" : [{
            "linkId" : "ndi-1",
            "text" : "Pain intensity",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA25855-0",
                "display" : "The pain is moderate at the moment."
              }
            }]
          },
          {
            "linkId" : "ndi-2",
            "text" : "Personal care (washing, dressing, etc.)",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 1
                }],
                "system" : "http://loinc.org",
                "code" : "LA25860-0",
                "display" : "I can look after myself normally but it causes extra pain."
              }
            }]
          },
          {
            "linkId" : "ndi-3",
            "text" : "Lifting",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA25867-5",
                "display" : "Pain prevents me lifting heavy weights off the floor, but I can manage if they are conveniently placed, for example on a table."
              }
            }]
          },
          {
            "linkId" : "ndi-4",
            "text" : "Reading",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA25873-3",
                "display" : "I can read as much as I want with moderate pain in my neck."
              }
            }]
          },
          {
            "linkId" : "ndi-5",
            "text" : "Headaches",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "system" : "http://loinc.org",
                "code" : "LA26367-5",
                "display" : "I have moderate headaches, which come frequently."
              }
            }]
          },
          {
            "linkId" : "ndi-6",
            "text" : "Concentration",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA25880-8",
                "display" : "I have a fair degree of difficulty in concentrating when I want to."
              }
            }]
          },
          {
            "linkId" : "ndi-7",
            "text" : "Work",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA25886-5",
                "display" : "I can do most of my usual work, but no more."
              }
            }]
          },
          {
            "linkId" : "ndi-8",
            "text" : "Driving",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA25892-3",
                "display" : "I can drive my car as long as I want with moderate pain in my neck."
              }
            }]
          },
          {
            "linkId" : "ndi-9",
            "text" : "Sleeping",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA25898-0",
                "display" : "My sleep is mildly disturbed (1-2 hrs sleepless)."
              }
            }]
          },
          {
            "linkId" : "ndi-10",
            "text" : "Recreation",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA25904-6",
                "display" : "I am able to engage in most, but not all of my usual recreation activities because of pain in my neck."
              }
            }]
          },
          {
            "linkId" : "total-score",
            "answer" : [{
              "valueDecimal" : 40
            }]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/QuestionnaireResponse/QuickDASHExample",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "QuickDASHExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>QuickDASH QuestionnaireResponse for John Doe. Score: 50.</p></div>"
          },
          "questionnaire" : "http://example.org/Questionnaire/QuickDASHQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "authored" : "2026-01-15T10:30:00Z",
          "author" : {
            "reference" : "Patient/PatientExample"
          },
          "item" : [{
            "linkId" : "qd-1",
            "text" : "Open a tight or new jar.",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "display" : "Moderate difficulty"
              }
            }]
          },
          {
            "linkId" : "qd-2",
            "text" : "Do heavy household chores (e.g., wash walls, wash floors).",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 4
                }],
                "display" : "Severe difficulty"
              }
            }]
          },
          {
            "linkId" : "qd-3",
            "text" : "Carry a shopping bag or briefcase.",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "display" : "Moderate difficulty"
              }
            }]
          },
          {
            "linkId" : "qd-4",
            "text" : "Wash your back.",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "display" : "Mild difficulty"
              }
            }]
          },
          {
            "linkId" : "qd-5",
            "text" : "Use a knife to cut food.",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "display" : "Mild difficulty"
              }
            }]
          },
          {
            "linkId" : "qd-6",
            "text" : "Recreational activities in which you take some force or impact through your arm, shoulder, or hand (e.g., golf, hammering, tennis, etc.).",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 4
                }],
                "display" : "Severe difficulty"
              }
            }]
          },
          {
            "linkId" : "qd-7",
            "text" : "During the past week, to what extent has your arm, shoulder, or hand problem interfered with your normal social activities with family, friends, neighbors, or groups?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "display" : "Moderately"
              }
            }]
          },
          {
            "linkId" : "qd-8",
            "text" : "During the past week, were you limited in your work or other regular daily activities as a result of your arm, shoulder, or hand problem?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 4
                }],
                "display" : "Very limited"
              }
            }]
          },
          {
            "linkId" : "qd-9",
            "text" : "Arm, shoulder, or hand pain",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "display" : "Moderate"
              }
            }]
          },
          {
            "linkId" : "qd-10",
            "text" : "Tingling (pins and needles) in your arm, shoulder, or hand",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "display" : "Mild"
              }
            }]
          },
          {
            "linkId" : "qd-11",
            "text" : "During the past week, how much difficulty have you had sleeping because of the pain in your arm, shoulder, or hand?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "display" : "Moderate difficulty"
              }
            }]
          },
          {
            "linkId" : "score",
            "answer" : [{
              "valueDecimal" : 50
            }]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/QuestionnaireResponse/MSKPGICExample",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "MSKPGICExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>PGIC QuestionnaireResponse for John Doe. Response: Very much improved.</p></div>"
          },
          "questionnaire" : "http://example.org/Questionnaire/MSKPGICQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "authored" : "2026-01-15T10:30:00Z",
          "author" : {
            "reference" : "Patient/PatientExample"
          },
          "item" : [{
            "linkId" : "pgic-1",
            "text" : "Since beginning treatment, how would you describe your overall change in pain, function, and quality of life?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 1
                }],
                "display" : "Very much improved"
              }
            }]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/QuestionnaireResponse/KOOSJRExample",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "KOOSJRExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>KOOS JR QuestionnaireResponse for John Doe. Total interval score: 50.012.</p></div>"
          },
          "questionnaire" : "http://example.org/Questionnaire/KOOSJRQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "authored" : "2026-01-15T10:30:00Z",
          "author" : {
            "reference" : "Patient/PatientExample"
          },
          "item" : [{
            "linkId" : "koosjr-1",
            "text" : "How severe is your knee stiffness after first wakening in the morning?",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA6751-7",
                "display" : "Moderate"
              }
            }]
          },
          {
            "linkId" : "koosjr-2",
            "text" : "Twisting/pivoting on your knee",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA6751-7",
                "display" : "Moderate"
              }
            }]
          },
          {
            "linkId" : "koosjr-3",
            "text" : "Straightening knee fully",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 1
                }],
                "system" : "http://loinc.org",
                "code" : "LA6752-5",
                "display" : "Mild"
              }
            }]
          },
          {
            "linkId" : "koosjr-4",
            "text" : "Going up or down stairs",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "system" : "http://loinc.org",
                "code" : "LA6750-9",
                "display" : "Severe"
              }
            }]
          },
          {
            "linkId" : "koosjr-5",
            "text" : "Standing upright",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA6751-7",
                "display" : "Moderate"
              }
            }]
          },
          {
            "linkId" : "koosjr-6",
            "text" : "Rising from sitting",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA6751-7",
                "display" : "Moderate"
              }
            }]
          },
          {
            "linkId" : "koosjr-7",
            "text" : "Bending to floor/picking up an object",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "system" : "http://loinc.org",
                "code" : "LA6750-9",
                "display" : "Severe"
              }
            }]
          },
          {
            "linkId" : "total-interval-score",
            "answer" : [{
              "valueDecimal" : 50.012
            }]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/QuestionnaireResponse/HOOSJRExample",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "HOOSJRExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>HOOS JR QuestionnaireResponse for John Doe. Total interval score: 55.985.</p></div>"
          },
          "questionnaire" : "http://example.org/Questionnaire/HOOSJRQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "authored" : "2026-01-15T10:30:00Z",
          "author" : {
            "reference" : "Patient/PatientExample"
          },
          "item" : [{
            "linkId" : "hoosjr-1",
            "text" : "Going up or down stairs",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA6751-7",
                "display" : "Moderate"
              }
            }]
          },
          {
            "linkId" : "hoosjr-2",
            "text" : "Walking on an uneven surface",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA6751-7",
                "display" : "Moderate"
              }
            }]
          },
          {
            "linkId" : "hoosjr-3",
            "text" : "Rising from sitting",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 2
                }],
                "system" : "http://loinc.org",
                "code" : "LA6751-7",
                "display" : "Moderate"
              }
            }]
          },
          {
            "linkId" : "hoosjr-4",
            "text" : "Bending to the floor/picking up an object",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 3
                }],
                "system" : "http://loinc.org",
                "code" : "LA6750-9",
                "display" : "Severe"
              }
            }]
          },
          {
            "linkId" : "hoosjr-5",
            "text" : "Lying in bed",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 1
                }],
                "system" : "http://loinc.org",
                "code" : "LA6752-5",
                "display" : "Mild"
              }
            }]
          },
          {
            "linkId" : "hoosjr-6",
            "text" : "Sitting",
            "answer" : [{
              "valueCoding" : {
                "extension" : [{
                  "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
                  "valueDecimal" : 1
                }],
                "system" : "http://loinc.org",
                "code" : "LA6752-5",
                "display" : "Mild"
              }
            }]
          },
          {
            "linkId" : "total-interval-score",
            "answer" : [{
              "valueDecimal" : 55.985
            }]
          }]
        }
      },
      {
        "fullUrl" : "http://example.org/QuestionnaireResponse/PROMISNRSExample",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "PROMISNRSExample",
          "meta" : {
            "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
          },
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\"><p>PROMIS Pain Intensity NRS QuestionnaireResponse for John Doe. Average pain (0-10): 6.</p></div>"
          },
          "questionnaire" : "http://example.org/Questionnaire/PROMISNRSQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/PatientExample"
          },
          "authored" : "2026-01-15T10:30:00Z",
          "author" : {
            "reference" : "Patient/PatientExample"
          },
          "item" : [{
            "linkId" : "nrs-1",
            "text" : "In the past 7 days, how would you rate your pain on average? (0-10)",
            "answer" : [{
              "valueInteger" : 6
            }]
          }]
        }
      }]
    }
  }]
}

```
