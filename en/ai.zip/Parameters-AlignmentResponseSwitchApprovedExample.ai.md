# Alignment Response - Switch Approved Example - CMS ACCESS Model API v0.9.11

## Example Parameters: Alignment Response - Switch Approved Example



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "AlignmentResponseSwitchApprovedExample",
  "meta" : {
    "profile" : ["https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-align-out"]
  },
  "parameter" : [{
    "name" : "result",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://dsacms.github.io/cmmi-access-model/CodeSystem/ACCESSAlignmentResultCS",
        "code" : "aligned-switch-approved",
        "display" : "Aligned and switch approved"
      }],
      "text" : "The request to switch the patient's alignment from a different provider after the 90-day lock in period is accepted and the patient is considered switched and now re-aligned."
    }
  }]
}

```
