# Resource CMS ACCESS Model API



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "cms.fhir.us.cmmi-access-model",
  "language" : "en",
  "url" : "https://dsacms.github.io/cmmi-access-model/ImplementationGuide/cms.fhir.us.cmmi-access-model",
  "version" : "0.9.12",
  "name" : "CMSAccessAPI",
  "title" : "CMS ACCESS Model API",
  "status" : "draft",
  "date" : "2026-06-10T23:08:55-04:00",
  "publisher" : "Global Alliant, Inc.",
  "contact" : [{
    "name" : "Global Alliant, Inc.",
    "telecom" : [{
      "system" : "url",
      "value" : "https://globalalliantinc.com"
    },
    {
      "system" : "email",
      "value" : "david.h@globalalliantinc.org"
    }]
  }],
  "description" : "Comprehensive Implementation Guide for all CMS ACCESS Model APIs including Eligibility, Alignment, Unalignment, and Data Reporting",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "US",
      "display" : "United States of America"
    }]
  }],
  "packageId" : "cms.fhir.us.cmmi-access-model",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.1.0"
  },
  {
    "id" : "hl7_fhir_us_core",
    "uri" : "http://hl7.org/fhir/us/core/ImplementationGuide/hl7.fhir.us.core",
    "packageId" : "hl7.fhir.us.core",
    "version" : "6.1.0"
  },
  {
    "id" : "hl7_fhir_us_carin_bb",
    "uri" : "http://hl7.org/fhir/us/carin-bb/ImplementationGuide/hl7.fhir.us.carin-bb",
    "packageId" : "hl7.fhir.us.carin-bb",
    "version" : "2.1.0"
  },
  {
    "id" : "hl7_fhir_uv_sdc",
    "uri" : "http://hl7.org/fhir/uv/sdc/ImplementationGuide/hl7.fhir.uv.sdc",
    "packageId" : "hl7.fhir.uv.sdc",
    "version" : "3.0.0"
  },
  {
    "id" : "hl7_fhir_uv_extensions_r4",
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.2.0"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "draft"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludettl"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "debug"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-all"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://dsacms.github.io/cmmi-access-model/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "wantGen-ttl"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "wantGen-ttl-html"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "draft"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludettl"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "debug"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-all"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://dsacms.github.io/cmmi-access-model/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "wantGen-ttl"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "wantGen-ttl-html"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "grouping" : [{
      "id" : "SharedResources",
      "name" : "Shared Resources",
      "description" : "Resources used across multiple ACCESS APIs"
    },
    {
      "id" : "EligibilityAPI",
      "name" : "Eligibility API Resources",
      "description" : "Resources specific to the ACCESS Eligibility API"
    },
    {
      "id" : "AlignmentAPI",
      "name" : "Alignment API Resources",
      "description" : "Resources specific to the ACCESS Alignment API"
    },
    {
      "id" : "UnalignmentAPI",
      "name" : "Unalignment API Resources",
      "description" : "Resources specific to the ACCESS Unalignment API"
    },
    {
      "id" : "DataReportingAPI",
      "name" : "Data Reporting API Resources",
      "description" : "Resources specific to the ACCESS Data Reporting API"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/ACCESSAlignmentAPICapabilityStatement"
      },
      "name" : "ACCESS Alignment API Capability Statement",
      "description" : "Describes the expected capabilities of systems implementing the ACCESS Alignment API for aligning patients to ACCESS participants.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-align-in"
      },
      "name" : "ACCESS Alignment Request Parameters",
      "description" : "This is the profile for the `$align` operation input parameters. When a patient wishes to switch from one ACCESS participant to another after the 90-day lock-in period, the `switchConsentAttestation` parameter must be set to `true` to indicate that the patient has provided consent to switch providers.",
      "exampleBoolean" : false,
      "groupingId" : "AlignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/ACCESSAlignmentResultCS"
      },
      "name" : "ACCESS Alignment Request Result Codes",
      "description" : "This codesystem defines codes indicating the result of a requested alignment.",
      "exampleBoolean" : false,
      "groupingId" : "AlignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-align-out"
      },
      "name" : "ACCESS Alignment Response Parameters",
      "description" : "This is the profile for the `$align` operation output parameters, which provide the results of the alignment request.",
      "exampleBoolean" : false,
      "groupingId" : "AlignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSAlignmentResultVS"
      },
      "name" : "ACCESS Alignment Result Value Set",
      "description" : "This value set includes all codes from the ACCESS Alignment Result code system.",
      "exampleBoolean" : false,
      "groupingId" : "AlignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSBHDiagnosisVS"
      },
      "name" : "ACCESS Behavioral Health (BH) Track Qualifying Diagnoses",
      "description" : "This value set contains ICD-10-CM diagnosis codes that qualify a patient for the ACCESS Model Behavioral Health (BH) track. Includes depression and anxiety disorder diagnoses.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-bh-condition"
      },
      "name" : "ACCESS BH Condition Profile",
      "description" : "The ACCESS BH Track Condition Profile is used for representing qualifying diagnoses for the Behavioral Health (BH) track. It constrains the [ACCESS Condition Profile](StructureDefinition-access-condition.html) to add a required binding to [ACCESSBHDiagnosisVS](ValueSet-ACCESSBHDiagnosisVS.html).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSBHClinicalExclusionDiagnosisVS"
      },
      "name" : "ACCESS BH Track Clinical Exclusion Diagnoses",
      "description" : "This value set contains ICD-10-CM diagnosis codes that represent clinical exclusions that would prevent a patient from participating in the ACCESS Model Behavioral Health (BH) track.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSCKMDiagnosisVS"
      },
      "name" : "ACCESS Cardio-Kidney-Metabolic (CKM) Track Qualifying Diagnoses",
      "description" : "This value set contains ICD-10-CM diagnosis codes that qualify a patient for the ACCESS Model Cardio-Kidney-Metabolic (CKM) track. Includes diabetes mellitus (all types), atherosclerotic cardiovascular disease (ASCVD), and chronic kidney disease (CKD stage 3) diagnoses.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-check-eligibility-in"
      },
      "name" : "ACCESS Check Eligibility Request Parameters",
      "description" : "This profile defines the input parameters for the `$check-eligibility` operation, which is used to determine if a patient is eligible for a specific ACCESS Model track.",
      "exampleBoolean" : false,
      "groupingId" : "EligibilityAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-check-eligibility-out"
      },
      "name" : "ACCESS Check Eligibility Response Parameters",
      "description" : "This is the profile for the `$check-eligibility` operation output parameters, which provide the results of the eligibility check.",
      "exampleBoolean" : false,
      "groupingId" : "EligibilityAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-ckm-condition"
      },
      "name" : "ACCESS CKM Track Condition Profile",
      "description" : "The ACCESS CKM Track Condition Profile is used for representing qualifying diagnoses for the Cardio-Kidney-Metabolic (CKM) track. It constrains the [ACCESS Condition Profile](StructureDefinition-access-condition.html) to add a required binding to [ACCESSCKMDiagnosisVS](ValueSet-ACCESSCKMDiagnosisVS.html).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-clinical-exclusion-condition"
      },
      "name" : "ACCESS Clinical Exclusion Condition",
      "description" : "The ACCESS Clinical Exclusion Condition profile is used for representing disqualifying conditions that would prevent a patient from being eligible for the ACCESS Model.",
      "exampleBoolean" : false,
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSClinicalExclusionDiagnosisVS"
      },
      "name" : "ACCESS Clinical Exclusion Diagnoses",
      "description" : "This value set contains ICD-10-CM diagnosis codes that represent clinical exclusions that would prevent a patient from participating in the ACCESS Model.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource:abstract"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-condition"
      },
      "name" : "ACCESS Condition Profile",
      "description" : "This profile constrains the US Core Condition Problems and Health Concerns Profile to require ICD-10-CM codes for the ACCESS Model. This ensures consistent diagnosis coding across all ACCESS APIs.  This profile also serves as the foundation for track-specific condition profiles:",
      "exampleBoolean" : false,
      "groupingId" : "SharedResources"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/ACCESSDataReportingAPICapabilityStatement"
      },
      "name" : "ACCESS Data Reporting API Capability Statement",
      "description" : "Describes the expected capabilities of systems implementing the ACCESS Data Reporting API for submitting clinical data for aligned patients.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-data-reporting-bundle"
      },
      "name" : "ACCESS Data Reporting Bundle",
      "description" : "The ACCESS Data Reporting Bundle Profile defines the structure for packaging clinical data submissions. It is a document-type Bundle that **SHALL** contain a Patient resource and an [ACCESS Data Reporting Composition](StructureDefinition-access-data-reporting-composition.html) resource.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-data-reporting-composition"
      },
      "name" : "ACCESS Data Reporting Composition",
      "description" : "The ACCESS Data Reporting Composition Profile defines the structure for organizing clinical data submissions to the ACCESS Model. This profile uses FHIR Composition sections to organize data by track (eCKM, CKM, MSK, BH) and measurement type.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSeCKMDiagnosisVS"
      },
      "name" : "ACCESS Early Cardio-Kidney-Metabolic (eCKM) Track Qualifying Diagnoses",
      "description" : "This value set contains ICD-10-CM diagnosis codes that qualify a patient for the ACCESS Model Early Cardio-Kidney-Metabolic (eCKM) track. Includes hypertension, dyslipidemia, prediabetes, and obesity diagnoses.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-eckm-condition"
      },
      "name" : "ACCESS eCKM Track Condition Profile",
      "description" : "The ACCESS eCKM Track Condition Profile is used for representing qualifying diagnoses for the Early Cardio-Kidney-Metabolic (eCKM) track. It constrains the [ACCESS Condition Profile](StructureDefinition-access-condition.html) to add a required binding to [ACCESSeCKMDiagnosisVS](ValueSet-ACCESSeCKMDiagnosisVS.html).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSCKMClinicalExclusionDiagnosisVS"
      },
      "name" : "ACCESS eCKM/CKM Track Clinical Exclusion Diagnoses",
      "description" : "This value set contains ICD-10-CM diagnosis codes that represent clinical exclusions that would prevent a patient from participating in the ACCESS Model early Cardio-Kidney-Metabolic (eCKM) and Cardio-Kidney-Metabolic (CKM) tracks.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/ACCESSEligibilityAPICapabilityStatement"
      },
      "name" : "ACCESS Eligibility API Capability Statement",
      "description" : "Describes the expected capabilities of systems implementing the ACCESS Eligibility API for checking patient eligibility for the ACCESS Model.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/ACCESSEligibilityResultCS"
      },
      "name" : "ACCESS Eligibility Result Codes",
      "description" : "This codesystem defines codes indicating the result of an eligibility check.",
      "exampleBoolean" : false,
      "groupingId" : "EligibilityAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSEligibilityResultVS"
      },
      "name" : "ACCESS Eligibility Result Value Set",
      "description" : "This value set includes all codes from the ACCESS Eligibility Result code system.",
      "exampleBoolean" : false,
      "groupingId" : "EligibilityAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/ACCESSEventTypeCS"
      },
      "name" : "ACCESS Event Types",
      "description" : "This codesystem defines codes for the types of events that trigger subscription notifications in the ACCESS Model.",
      "exampleBoolean" : false,
      "groupingId" : "AlignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSEventTypeVS"
      },
      "name" : "ACCESS Event Types Value Set",
      "description" : "This value set includes all codes from the ACCESS Event Types code system.",
      "exampleBoolean" : false,
      "groupingId" : "AlignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/ACCESSTrackCS"
      },
      "name" : "ACCESS Model Tracks",
      "description" : "This codesystem defines codes for each of the ACCESS Model tracks.",
      "exampleBoolean" : false,
      "groupingId" : "SharedResources"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSTrackVS"
      },
      "name" : "ACCESS Model Tracks Value Set",
      "description" : "This value set includes all codes from the ACCESS Model Tracks code system.",
      "exampleBoolean" : false,
      "groupingId" : "SharedResources"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSMSKClinicalExclusionDiagnosisVS"
      },
      "name" : "ACCESS MSK Track Clinical Exclusion Diagnoses",
      "description" : "This value set contains ICD-10-CM diagnosis codes that represent clinical exclusions that would prevent a patient from participating in the ACCESS Model Musculoskeletal (MSK) track.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-msk-condition"
      },
      "name" : "ACCESS MSK Track Condition Profile",
      "description" : "The ACCESS MSK Track Condition Profile is used for representing qualifying diagnoses for the Musculoskeletal (MSK) track. It constrains the [ACCESS Condition Profile](StructureDefinition-access-condition.html) to add a required binding to [ACCESSMSKDiagnosisVS](ValueSet-ACCESSMSKDiagnosisVS.html).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSMSKDiagnosisVS"
      },
      "name" : "ACCESS Musculoskeletal (MSK) Track Qualifying Diagnoses",
      "description" : "This value set contains ICD-10-CM diagnosis codes that qualify a patient for the ACCESS Model Musculoskeletal (MSK) track. Includes osteoarthritis, other arthropathies and joint disorders, spine and structural disorders, degenerative spine disease, back pain and radiculopathy, soft tissue/tendon/bursa disorders, and peripheral nerve and plexus disorders.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/ACCESSReportDataCompositionSectionCS"
      },
      "name" : "ACCESS Report Data Composition Section Codes",
      "description" : "This codesystem defines additional codes for composition sections used in ACCESS Model data reporting when LOINC codes are not available.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-report-data-in"
      },
      "name" : "ACCESS Report Data Parameters",
      "description" : "This is the profile for the `$report-data` operation input parameters.",
      "exampleBoolean" : false,
      "groupingId" : "DataReportingAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-report-data-out"
      },
      "name" : "ACCESS Report Data Response Parameters",
      "description" : "This is the profile for the `$report-data` operation output parameters, which provide the results of the data reporting.",
      "exampleBoolean" : false,
      "groupingId" : "DataReportingAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/ACCESSReportDataResultCS"
      },
      "name" : "ACCESS Report Data Result Codes",
      "description" : "This codesystem defines the codes indicating the result of a data reporting submission.",
      "exampleBoolean" : false,
      "groupingId" : "DataReportingAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSReportDataResultVS"
      },
      "name" : "ACCESS Report Data Result Value Set",
      "description" : "This value set includes all codes from the ACCESS Report Data Result code system.",
      "exampleBoolean" : false,
      "groupingId" : "DataReportingAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/ACCESSReportTypeCS"
      },
      "name" : "ACCESS Report Type Codes",
      "description" : "This codesystem defines the codes indicating the type of the data report submission.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSReportTypeVS"
      },
      "name" : "ACCESS Report Type Value Set",
      "description" : "This value set includes all codes from the ACCESS Report Type code system.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-submission-status-out"
      },
      "name" : "ACCESS Submission Status Response Parameters",
      "description" : "This is the profile for the $submission-status operation output parameters (generic for all APIs). When the result indicates a validation error, the optional 'issues' parameter MAY contain an OperationOutcome resource with detailed validation error information to help implementers understand and correct the submission.",
      "exampleBoolean" : false,
      "groupingId" : "SharedResources"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/ACCESSUnalignmentAPICapabilityStatement"
      },
      "name" : "ACCESS Unalignment API Capability Statement",
      "description" : "Describes the expected capabilities of systems implementing the ACCESS Unalignment API for removing patient alignments from ACCESS participants.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/ACCESSUnalignmentReasonCS"
      },
      "name" : "ACCESS Unalignment Reason Codes",
      "description" : "This codesystem defines the codes indicating the reason for the requested unalignment.",
      "exampleBoolean" : false,
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSUnalignmentReasonVS"
      },
      "name" : "ACCESS Unalignment Reason Value Set",
      "description" : "This value set includes all codes from the ACCESS Unalignment Reason code system.",
      "exampleBoolean" : false,
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-unalign-in"
      },
      "name" : "ACCESS Unalignment Request Parameters",
      "description" : "This is the profile for the `$unalign` operation input parameters.",
      "exampleBoolean" : false,
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/ACCESSUnalignmentResultCS"
      },
      "name" : "ACCESS Unalignment Request Result Codes",
      "description" : "This codesystem defines the codes indicating the result of a requested unalignment.",
      "exampleBoolean" : false,
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/access-unalign-out"
      },
      "name" : "ACCESS Unalignment Response Parameters",
      "description" : "This is the profile for the `$unalign` operation output parameters, which provide the results of the unalignment request.",
      "exampleBoolean" : false,
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ACCESSUnalignmentResultVS"
      },
      "name" : "ACCESS Unalignment Result Value Set",
      "description" : "This value set includes all codes from the ACCESS Unalignment Result code system.",
      "exampleBoolean" : false,
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      }],
      "reference" : {
        "reference" : "OperationDefinition/Align"
      },
      "name" : "Alignment Request",
      "description" : "The **$align** operation determines if the patient can be aligned to a participant so that the participant can start providing care to the patient under the ACCESS Model. If the patient can be aligned, the patient will be aligned with the participant for a specific ACCESS track.",
      "exampleBoolean" : false,
      "groupingId" : "AlignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/AlignmentRequestExample"
      },
      "name" : "Alignment Request Example",
      "description" : "Example of parameters for aligning a patient to the ACCESS Model",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-align-in|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/AlignmentRequestWithSwitchConsentExample"
      },
      "name" : "Alignment Request with Switch Consent Example",
      "description" : "Example of parameters for aligning a patient with switch consent attestation",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-align-in|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/AlignmentResponseAlignedExample"
      },
      "name" : "Alignment Response - Aligned Example",
      "description" : "Example response indicating successful patient alignment",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-align-out|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/AlignmentResponseSwitchApprovedExample"
      },
      "name" : "Alignment Response - Switch Approved Example",
      "description" : "Example response indicating successful provider switch",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-align-out|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/BHPGICQuestionnaireExample"
      },
      "name" : "BH PGIC Questionnaire",
      "description" : "Behavioral Health Patient Global Impression of Change",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/BHPGICExample"
      },
      "name" : "BH PGIC QuestionnaireResponse Example",
      "description" : "Example Patient Global Impression of Change for the BH track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/BHReportDataBundleExample"
      },
      "name" : "BH Report Data Bundle Example",
      "description" : "Example of a complete report data bundle for the BH track",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-data-reporting-bundle|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      }],
      "reference" : {
        "reference" : "Composition/BHReportDataCompositionExample"
      },
      "name" : "BH Report Data Composition Example",
      "description" : "Example composition for reporting data for the BH track",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-data-reporting-composition|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/BHReportDataRequestExample"
      },
      "name" : "BH Report Data Request Example",
      "description" : "Example of parameters for submitting a BH track data report",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-in|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/WHODASExample"
      },
      "name" : "BH WHODAS 2.0 QuestionnaireResponse Example",
      "description" : "Example WHODAS 2.0 (12-item) QuestionnaireResponse for the BH track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/BloodPressureExample"
      },
      "name" : "Blood Pressure Example",
      "description" : "Example of blood pressure observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/BloodPressureExample2"
      },
      "name" : "Blood Pressure Example 2",
      "description" : "Second example of blood pressure observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/BloodPressureExample3"
      },
      "name" : "Blood Pressure Example 3",
      "description" : "Third example of blood pressure observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/BMIExample"
      },
      "name" : "BMI Example",
      "description" : "Example body mass index observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/BodyWeightExample"
      },
      "name" : "Body Weight Example",
      "description" : "Example body weight observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      }],
      "reference" : {
        "reference" : "OperationDefinition/CheckEligibility"
      },
      "name" : "Check Eligibility Request",
      "description" : "The **$check-eligibility** operation allows a participant to submit basic information on a patient who they believe will be a good candidate for the ACCESS model and who wants to be part of the ACCESS Model. The participant can use this API to do a quick check on which patients may be eligible before officially submitting the patient's information for consideration and inclusion in the ACCESS Model.",
      "exampleBoolean" : false,
      "groupingId" : "EligibilityAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/CheckEligibilityRequestExample"
      },
      "name" : "Check Eligibility Request Example",
      "description" : "Example of parameters for checking patient eligibility for the ACCESS Model",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-check-eligibility-in|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/CheckEligibilityResponseEligibleExample"
      },
      "name" : "Check Eligibility Response - Eligible Example",
      "description" : "Example response indicating patient is eligible for the ACCESS Model",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-check-eligibility-out|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/CKMReportDataBundleExample"
      },
      "name" : "CKM Report Data Bundle Example",
      "description" : "Example of a complete report data bundle for the CKM/eCKM track",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-data-reporting-bundle|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      }],
      "reference" : {
        "reference" : "Composition/CKMReportDataCompositionExample"
      },
      "name" : "CKM Report Data Composition Example",
      "description" : "Example composition for reporting data for the CKM/eCKM track",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-data-reporting-composition|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/CKMReportDataRequestExample"
      },
      "name" : "CKM Report Data Request Example",
      "description" : "Example of parameters for submitting a CKM track data report",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-in|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/ConditionHypertensionExample"
      },
      "name" : "Condition Example - Essential Hypertension",
      "description" : "Example condition for Essential Hypertension using ACCESS eCKM Track Condition profile with required ICD-10 coding",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-eckm-condition|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/ConditionDepressionExample"
      },
      "name" : "Condition Example - Major Depressive Disorder",
      "description" : "Example condition for Major Depressive Disorder using ACCESS BH Track Condition profile with required ICD-10 coding",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-bh-condition|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/ConditionOsteoarthritisExample"
      },
      "name" : "Condition Example - Osteoarthritis",
      "description" : "Example condition for Osteoarthritis using ACCESS MSK Track Condition profile with required ICD-10 coding",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-msk-condition|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/ConditionDiabetesExample"
      },
      "name" : "Condition Example - Type 2 Diabetes",
      "description" : "Example condition for Type 2 Diabetes Mellitus using ACCESS CKM Track Condition profile with required ICD-10 coding",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-ckm-condition|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/eCKMReportDataBundleExample"
      },
      "name" : "eCKM Report Data Bundle Example",
      "description" : "Example of a complete report data bundle for the eCKM track",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-data-reporting-bundle|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      }],
      "reference" : {
        "reference" : "Composition/eCKMReportDataCompositionExample"
      },
      "name" : "eCKM Report Data Composition Example",
      "description" : "Example composition for reporting data for the eCKM track",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-data-reporting-composition|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/eCKMReportDataRequestExample"
      },
      "name" : "eCKM Report Data Request Example",
      "description" : "Example of parameters for submitting an eCKM track data report",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-in|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/eGFRExample"
      },
      "name" : "eGFR Example",
      "description" : "Example estimated glomerular filtration rate observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/ESRDConditionExample"
      },
      "name" : "End Stage Renal Disease Condition Example",
      "description" : "Active ESRD diagnosis that disqualifies patient from ACCESS Model",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-clinical-exclusion-condition|0.9.12",
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/GAD7QuestionnaireExample"
      },
      "name" : "GAD-7 Questionnaire",
      "description" : "Generalized Anxiety Disorder-7 assessment",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/AnxietyGAD7Example"
      },
      "name" : "GAD-7 QuestionnaireResponse Example",
      "description" : "Example GAD-7 anxiety assessment for the BH track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/HbA1cExample"
      },
      "name" : "HbA1c Example",
      "description" : "Example hemoglobin A1c observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/HDLCholesterolExample"
      },
      "name" : "HDL Cholesterol Example",
      "description" : "Example HDL cholesterol observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/HOOSJRQuestionnaireExample"
      },
      "name" : "HOOS JR Questionnaire",
      "description" : "Questionnaire for HOOS JR score reporting",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/HOOSJRExample"
      },
      "name" : "HOOS JR QuestionnaireResponse Example",
      "description" : "Example Hip Dysfunction and Osteoarthritis Outcome Score for Joint Replacement (HOOS JR) QuestionnaireResponse for the MSK track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/KOOSJRQuestionnaireExample"
      },
      "name" : "KOOS JR Questionnaire",
      "description" : "Questionnaire for KOOS JR score reporting",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/KOOSJRExample"
      },
      "name" : "KOOS JR QuestionnaireResponse Example",
      "description" : "Example Knee Injury and Osteoarthritis Outcome Score for Joint Replacement (KOOS JR) QuestionnaireResponse for the MSK track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/LDLCholesterolExample"
      },
      "name" : "LDL Cholesterol Example",
      "description" : "Example LDL cholesterol observation for the CKM/eCKMtrack",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/LDLDiagnosticReportExample"
      },
      "name" : "LDL-C DiagnosticReport Example",
      "description" : "Example LDL-C diagnostic report for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/LipidPanelDiagnosticReportExample"
      },
      "name" : "Lipid Panel DiagnosticReport Example",
      "description" : "Example lipid panel diagnostic report for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/MSKReportDataBundleExample"
      },
      "name" : "MSK Data Reporting Bundle Example",
      "description" : "Example of a complete report data bundle for the MSK track",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-data-reporting-bundle|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      }],
      "reference" : {
        "reference" : "Composition/MSKReportDataCompositionExample"
      },
      "name" : "MSK Data Reporting Composition Example",
      "description" : "Example composition for reporting data for the MSK track",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-data-reporting-composition|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/MSKPGICQuestionnaireExample"
      },
      "name" : "MSK PGIC Questionnaire",
      "description" : "Questionnaire for MSK Patient Global Impression of Change (PGIC) reporting",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/MSKPGICExample"
      },
      "name" : "MSK PGIC QuestionnaireResponse Example",
      "description" : "Example Patient Global Impression of Change QuestionnaireResponse for the MSK track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/MSKReportDataRequestExample"
      },
      "name" : "MSK Report Data Request Example",
      "description" : "Example of parameters for submitting a MSK track data report",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-in|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/NeckDisabilityIndexQuestionnaireExample"
      },
      "name" : "Neck Disability Index Questionnaire",
      "description" : "Questionnaire for Neck Disability Index (NDI) score reporting",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/NeckDisabilityIndexExample"
      },
      "name" : "Neck Disability Index QuestionnaireResponse Example",
      "description" : "Example Neck Disability Index (NDI) QuestionnaireResponse for the MSK track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/OrganizationExample"
      },
      "name" : "Organization Example",
      "description" : "Example organization for ACCESS Model examples",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/OswestryDisabilityIndexQuestionnaireExample"
      },
      "name" : "Oswestry Disability Index Questionnaire",
      "description" : "Questionnaire for Oswestry Disability Index (ODI) score reporting",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/OswestryDisabilityIndexExample"
      },
      "name" : "Oswestry Disability Index QuestionnaireResponse Example",
      "description" : "Example Oswestry Disability Index (ODI) QuestionnaireResponse for the MSK track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/PatientExample"
      },
      "name" : "Patient Example",
      "description" : "Example patient for ACCESS Model examples",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/PatientESRDExample"
      },
      "name" : "Patient with ESRD - Unalignment Example",
      "description" : "Patient Jane Smith who has developed ESRD making her ineligible for ACCESS Model",
      "exampleBoolean" : true,
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/PHQ9QuestionnaireExample"
      },
      "name" : "PHQ-9 Questionnaire",
      "description" : "Patient Health Questionnaire-9 for depression screening",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/DepressionPHQ9Example"
      },
      "name" : "PHQ-9 QuestionnaireResponse Example",
      "description" : "Example PHQ-9 depression assessment for the BH track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      }],
      "reference" : {
        "reference" : "Practitioner/PractitionerExample"
      },
      "name" : "Practitioner Example",
      "description" : "Example practitioner for ACCESS Model examples",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/PROMISNRSQuestionnaireExample"
      },
      "name" : "PROMIS Pain Intensity NRS Questionnaire",
      "description" : "Questionnaire for PROMIS Pain Intensity NRS v1.0 score reporting",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/PROMISNRSExample"
      },
      "name" : "PROMIS Pain Intensity NRS QuestionnaireResponse Example",
      "description" : "Example PROMIS Pain Intensity NRS QuestionnaireResponse for the MSK track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/PROMISPainInterferenceCATQuestionnaireExample"
      },
      "name" : "PROMIS Pain Interference CAT Questionnaire",
      "description" : "Questionnaire for PROMIS Pain Interference CAT score reporting",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/PROMISPainInterferenceCATExample"
      },
      "name" : "PROMIS Pain Interference CAT QuestionnaireResponse Example",
      "description" : "Example PROMIS Pain Interference CAT QuestionnaireResponse for the MSK track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/PROMISPainInterferenceSFQuestionnaireExample"
      },
      "name" : "PROMIS Pain Interference Short Form 6a Questionnaire",
      "description" : "Questionnaire for PROMIS Pain Interference Short Form 6a score reporting",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/PROMISPainInterferenceSFExample"
      },
      "name" : "PROMIS Pain Interference Short Form 6a QuestionnaireResponse Example",
      "description" : "Example PROMIS Pain Interference (PI) Short Form 6a QuestionnaireResponse for the MSK track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/PROMISPhysicalFunctionCATQuestionnaireExample"
      },
      "name" : "PROMIS Physical Function CAT Questionnaire",
      "description" : "Questionnaire for PROMIS Physical Function CAT score reporting",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/PROMISPhysicalFunctionCATExample"
      },
      "name" : "PROMIS Physical Function CAT QuestionnaireResponse Example",
      "description" : "Example PROMIS Physical Function CAT QuestionnaireResponse for the MSK track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/PROMISPhysicalFunctionQuestionnaireExample"
      },
      "name" : "PROMIS Physical Function Short Form 6b Questionnaire",
      "description" : "Questionnaire for PROMIS Physical Function Short Form 6b score reporting",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/PROMISPhysicalFunctionExample"
      },
      "name" : "PROMIS Physical Function Short Form 6b QuestionnaireResponse Example",
      "description" : "Example PROMIS Physical Function (PF) Short Form 6b QuestionnaireResponse for the MSK track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/QuickDASHQuestionnaireExample"
      },
      "name" : "QuickDASH Questionnaire",
      "description" : "Questionnaire for QuickDASH score reporting",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/QuickDASHExample"
      },
      "name" : "QuickDASH QuestionnaireResponse Example",
      "description" : "Example QuickDASH QuestionnaireResponse for the MSK track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/ReportDataRequestExample"
      },
      "name" : "Report Data Request Example",
      "description" : "Example of parameters for submitting data report",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-in|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/ReportDataResponseDuplicateExample"
      },
      "name" : "Report Data Response - Duplicate Example",
      "description" : "Example response indicating data submission is a duplicate",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-out|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/ReportDataResponseIncompleteDataExample"
      },
      "name" : "Report Data Response - Incomplete Data Example",
      "description" : "Example response indicating data submission is missing required elements",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-out|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/ReportDataResponseIncorrectTrackExample"
      },
      "name" : "Report Data Response - Incorrect Track Example",
      "description" : "Example response indicating data doesn't match patient's aligned track",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-out|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/ReportDataResponsePatientNotAlignedExample"
      },
      "name" : "Report Data Response - Patient Not Aligned Example",
      "description" : "Example response indicating patient is not aligned",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-out|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/ReportDataResponseReportingPeriodClosedExample"
      },
      "name" : "Report Data Response - Reporting Period Closed Example",
      "description" : "Example response indicating the reporting period has closed",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-out|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/ReportDataResponseSuccessExample"
      },
      "name" : "Report Data Response - Success Example",
      "description" : "Example response indicating successful report data submission",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-report-data-out|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      }],
      "reference" : {
        "reference" : "OperationDefinition/SubmissionStatus"
      },
      "name" : "Submission Status",
      "description" : "The **$submission-status** operation allows the client to check the status of any asynchronous ACCESS operation submission. This is a shared operation used by all ACCESS APIs. The specific result codes returned depend on which operation created the submission: [ACCESSEligibilityResultVS](ValueSet-ACCESSEligibilityResultVS.html) for $check-eligibility, [ACCESSAlignmentResultVS](ValueSet-ACCESSAlignmentResultVS.html) for $align, [ACCESSUnalignmentResultVS](ValueSet-ACCESSUnalignmentResultVS.html) for $unalign, and [ACCESSReportDataResultVS](ValueSet-ACCESSReportDataResultVS.html) for $report-data.",
      "exampleBoolean" : false,
      "groupingId" : "SharedResources"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationOutcome"
      }],
      "reference" : {
        "reference" : "OperationOutcome/SubmissionStatusOperationOutcomeExample"
      },
      "name" : "Submission Status OperationOutcome Example",
      "description" : "Example OperationOutcome showing detailed guidance for an incomplete data submission, included in the optional 'issues' parameter of submission status responses",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/SubmissionStatusResponseExample"
      },
      "name" : "Submission Status Response Example",
      "description" : "Example response for submission status check",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-submission-status-out|0.9.12"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      }],
      "reference" : {
        "reference" : "OperationDefinition/ReportData"
      },
      "name" : "Submit Data Report",
      "description" : "The **$report-data** operation allows a participant to submit data reporting information for the ACCESS model.",
      "exampleBoolean" : false,
      "groupingId" : "DataReportingAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/TotalCholesterolExample"
      },
      "name" : "Total Cholesterol Example",
      "description" : "Example total cholesterol observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/TriglyceridesExample"
      },
      "name" : "Triglycerides Example",
      "description" : "Example triglycerides observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/uACRExample"
      },
      "name" : "uACR Example",
      "description" : "Example urine albumin-creatinine ratio observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      }],
      "reference" : {
        "reference" : "OperationDefinition/Unalign"
      },
      "name" : "Unalignment Request",
      "description" : "The **$unalign** operation supports the ability to manually unalign a patient from the participant in a specific ACCESS track. There are a specific set of reasons a patient can be unaligned such as the patient has moved outside of the care radius of the participant or despite good faith efforts, communication with the patient has ceased. When unalignment is successful, the system automatically sends notifications to the participant confirming the unalignment, then all FHIR subscriptions created during the original alignment are cancelled to prevent future erroneous notifications.",
      "exampleBoolean" : false,
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/UnalignmentRequestESRDExample"
      },
      "name" : "Unalignment Request - ESRD Example",
      "description" : "Example of unalignment request for patient who developed ESRD (no longer clinically eligible)",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-unalign-in|0.9.12",
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/UnalignmentRequestExample"
      },
      "name" : "Unalignment Request Example",
      "description" : "Example of parameters for unaligning a patient from the ACCESS Model",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-unalign-in|0.9.12",
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/UnalignmentResponseUnalignedExample"
      },
      "name" : "Unalignment Response - Unaligned Example",
      "description" : "Example response indicating successful patient unalignment",
      "exampleCanonical" : "https://dsacms.github.io/cmmi-access-model/StructureDefinition/access-unalign-out|0.9.12",
      "groupingId" : "UnalignmentAPI"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/WaistCircumferenceExample"
      },
      "name" : "Waist Circumference Example",
      "description" : "Example waist circumference observation for the CKM/eCKM track",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      }],
      "reference" : {
        "reference" : "Questionnaire/WHODASQuestionnaireExample"
      },
      "name" : "WHODAS 2.0 12-item Questionnaire",
      "description" : "World Health Organization Disability Assessment Schedule 2.0 (12-item)",
      "exampleBoolean" : true
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "conformance.html"
        }],
        "nameUrl" : "conformance.html",
        "title" : "Conformance Expectations",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "artifacts.html"
        }],
        "nameUrl" : "artifacts.html",
        "title" : "Artifacts",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "downloads.html"
        }],
        "nameUrl" : "downloads.html",
        "title" : "Downloads",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "changelog.html"
        }],
        "nameUrl" : "changelog.html",
        "title" : "Change Log",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/assets"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
