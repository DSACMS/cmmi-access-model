# Oswestry Disability Index QuestionnaireResponse Example - CMS ACCESS Model API v0.9.11

## Example QuestionnaireResponse: Oswestry Disability Index QuestionnaireResponse Example

Oswestry Disability Index QuestionnaireResponse for John Doe. Score: 36.



## Resource Content

```json
{
  "resourceType" : "QuestionnaireResponse",
  "id" : "OswestryDisabilityIndexExample",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-questionnaireresponse|6.1.0"]
  },
  "questionnaire" : "http://example.org/Questionnaire/OswestryDisabilityIndexQuestionnaire",
  "status" : "completed",
  "subject" : {
    "reference" : "Patient/PatientExample"
  },
  "authored" : "2026-01-15T10:30:00Z",
  "author" : {
    "reference" : "Patient/PatientExample"
  },
  "item" : [{
    "linkId" : "odi-1",
    "text" : "Pain intensity",
    "answer" : [{
      "valueCoding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
          "valueDecimal" : 2
        }],
        "display" : "The pain is moderate at the moment."
      }
    }]
  },
  {
    "linkId" : "odi-2",
    "text" : "Personal care (washing, dressing, etc.)",
    "answer" : [{
      "valueCoding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
          "valueDecimal" : 1
        }],
        "display" : "I can look after myself normally but it is very painful."
      }
    }]
  },
  {
    "linkId" : "odi-3",
    "text" : "Lifting",
    "answer" : [{
      "valueCoding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
          "valueDecimal" : 3
        }],
        "display" : "Pain prevents me lifting heavy weights off the floor, but I can manage if they are conveniently placed e.g. on a table."
      }
    }]
  },
  {
    "linkId" : "odi-4",
    "text" : "Walking",
    "answer" : [{
      "valueCoding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
          "valueDecimal" : 1
        }],
        "display" : "Pain prevents me from walking more than one mile."
      }
    }]
  },
  {
    "linkId" : "odi-5",
    "text" : "Sitting",
    "answer" : [{
      "valueCoding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
          "valueDecimal" : 2
        }],
        "display" : "Pain prevents me from sitting for more than one hour."
      }
    }]
  },
  {
    "linkId" : "odi-6",
    "text" : "Standing",
    "answer" : [{
      "valueCoding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
          "valueDecimal" : 2
        }],
        "display" : "Pain prevents me from standing for more than 1 hour."
      }
    }]
  },
  {
    "linkId" : "odi-7",
    "text" : "Sleeping",
    "answer" : [{
      "valueCoding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
          "valueDecimal" : 1
        }],
        "display" : "My sleep is occasionally interrupted by pain."
      }
    }]
  },
  {
    "linkId" : "odi-8",
    "text" : "Sex life (if applicable)",
    "answer" : [{
      "valueCoding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
          "valueDecimal" : 2
        }],
        "display" : "My sex life is nearly normal but is very painful."
      }
    }]
  },
  {
    "linkId" : "odi-9",
    "text" : "Social life",
    "answer" : [{
      "valueCoding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
          "valueDecimal" : 3
        }],
        "display" : "Pain has restricted my social life and I do not go out as often."
      }
    }]
  },
  {
    "linkId" : "odi-10",
    "text" : "Traveling",
    "answer" : [{
      "valueCoding" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
          "valueDecimal" : 2
        }],
        "display" : "Pain is bad but I am able to manage trips over two hours."
      }
    }]
  },
  {
    "linkId" : "score",
    "answer" : [{
      "valueDecimal" : 38
    }]
  }]
}

```
